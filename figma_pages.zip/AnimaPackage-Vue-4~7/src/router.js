import Vue from "vue";
import Router from "vue-router";
import Screen from "./components/Screen";
import AI from "./components/AI";
import X1 from "./components/X1";
import Screen2 from "./components/Screen2";
import Screen3 from "./components/Screen3";
import U4355u4450u4352u4469u4361u4469u4527 from "./components/U4355u4450u4352u4469u4361u4469u4527";
import U4355u4450u4352u4469u4361u4469u45272 from "./components/U4355u4450u4352u4469u4361u4469u45272";
import {
  x1Data,
  screen3Data,
  u4355u4450u4352u4469u4361u4469u4527Data,
  u4355u4450u4352u4469u4361u4469u45272Data,
} from "./data";

Vue.use(Router);

export default new Router({
  mode: "history",
  routes: [
    {
      path: "/u4369u4455u4540u4352u4449u4352u4449-u4353u4467u4544u4354u4449u4539u4361u4467u4536u4354u4469u4355u4449",
      component: Screen,
      props: { text1: "평가가 끝났습니다!", text: "확인하기" },
    },
    {
      path: "/aiu4352u4449-u4369u4455u4540u4352u4449u4364u4462u4540u4363u4469u4536u4354u4469u4355u4449",
      component: AI,
      props: { ai: "AI가 당신의 시나리오를 <br />평가하는 중 입니다" },
    },
    {
      path:
        "/u4361u4469u4354u4449u4357u4469u4363u4457-u4364u4449u4520u4361u4453u4540-u4361u4467u4368u4454u4363u4469u4364u4469-1",
      component: X1,
      props: { ...x1Data },
    },
    {
      path:
        "/u4366u4453u4538u4359u4453u4523u4365u4450-u4361u4469u4354u4449u4357u4469u4363u4457u4352u4449-u4363u4457u4352u4457-u4363u4469u4539u4361u4467u4536u4354u4469u4355u4449",
      component: Screen2,
      props: { text4: "첫번째 시나리오가 <br />오고 있습니다" },
    },
    {
      path: "/u4363u4455u4540u4370u4458-u4361u4453u4523u4368u4450u4520",
      component: Screen3,
      props: { ...screen3Data },
    },
    {
      path:
        "/u4355u4450u4352u4469u4361u4469u4527-u4363u4455u4540u4370u4458-u4361u4453u4523u4368u4450u4520-u4363u4458u4523u4357u4461",
      component: U4355u4450u4352u4469u4361u4469u4527,
      props: { ...u4355u4450u4352u4469u4361u4469u4527Data },
    },
    {
      path: "*",
      component: U4355u4450u4352u4469u4361u4469u45272,
      props: { ...u4355u4450u4352u4469u4361u4469u45272Data },
    },
  ],
});
