<template>
  <div class="container-center-horizontal">
    <div
      class="u4361u4469u4354u4449u4357u4469u4363u4457-u4364u4449u4520u4361u4453u4540-u4361u4467u4368u4454u4363u4469u4364u4469-1 screen"
    >
      <div class="overlap-group">
        <div class="overlap-group1">
          <div class="rectangle-516"></div>
          <div class="rectangle-517"></div>
          <img
            class="line-1"
            src="https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e134a66306b18b48bce9f/img/line-1.svg"
            alt="Line 1"
          />
          <img
            class="line-2"
            src="https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e134a66306b18b48bce9f/img/line-2.svg"
            alt="Line 2"
          />
          <img
            class="line-3"
            src="https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e134a66306b18b48bce9f/img/line-3.svg"
            alt="Line 3"
          />
          <img
            class="line-4"
            src="https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e134a66306b18b48bce9f/img/line-4.svg"
            alt="Line 4"
          />
          <img
            class="line-5"
            src="https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e134a66306b18b48bce9f/img/line-5.svg"
            alt="Line 5"
          />
          <div class="text-2 manrope-semi-bold-white-24px">{{ text2 }}</div>
          <div class="date manrope-semi-bold-white-16px">{{ date }}</div>
          <div class="place manrope-semi-bold-white-12px">{{ place }}</div>
          <div class="cut manrope-semi-bold-white-12px">{{ cut }}</div>
          <div class="number manrope-semi-bold-white-16px">{{ number }}</div>
          <h1 class="title">{{ title }}</h1>
          <div class="text-3 manrope-semi-bold-white-24px">{{ text3 }}</div>
        </div>
        <div class="indicators-container">
          <div class="shape-1"></div>
          <div class="shape"></div>
          <div class="shape"></div>
          <div class="shape"></div>
          <div class="shape"></div>
        </div>
      </div>
      <div class="button-1">
        <p class="text-4 manrope-semi-bold-white-32px">{{ text1 }}</p>
      </div>
      <div class="card-container">
        <div class="card">
          <container :name="container1Props.name" />
          <p class="paragraph" v-html="paragraph1"></p>
        </div>
        <div class="card-1">
          <container :name="container2Props.name" />
          <div class="paragraph-1">{{ paragraph2 }}</div>
        </div>
      </div>
      <div class="button-2">
        <div class="text-5 valign-text-middle">{{ text4 }}</div>
      </div>
    </div>
  </div>
</template>

<script>
import Container from "./Container";
export default {
  name: "X1",
  components: {
    Container,
  },
  props: [
    "text2",
    "date",
    "place",
    "cut",
    "number",
    "title",
    "text3",
    "text1",
    "paragraph1",
    "paragraph2",
    "text4",
    "container1Props",
    "container2Props",
  ],
};
</script>

<style>
.u4361u4469u4354u4449u4357u4469u4363u4457-u4364u4449u4520u4361u4453u4540-u4361u4467u4368u4454u4363u4469u4364u4469-1 {
  align-items: center;
  background-color: var(--eerie-black);
  display: flex;
  flex-direction: column;
  height: 1024px;
  padding: 21px 52px;
  width: 1440px;
}

.overlap-group {
  align-self: flex-start;
  height: 129px;
  margin-top: 23px;
  position: relative;
  width: 1333px;
}

.overlap-group1 {
  height: 129px;
  left: 0;
  position: absolute;
  top: 0;
  width: 1333px;
}

.rectangle-516 {
  background-color: var(--black);
  border: 1px solid;
  border-color: #6d6464;
  border-radius: 22px;
  height: 126px;
  left: 0;
  position: absolute;
  top: 3px;
  width: 1333px;
}

.rectangle-517 {
  background-color: var(--black);
  border: 1px solid;
  border-color: #918787;
  height: 126px;
  left: 1108px;
  position: absolute;
  top: 3px;
  width: 225px;
}

.line-1 {
  height: 1px;
  left: 1109px;
  object-fit: cover;
  position: absolute;
  top: 65px;
  width: 224px;
}

.line-2 {
  height: 126px;
  left: 210px;
  object-fit: cover;
  position: absolute;
  top: 3px;
  width: 1px;
}

.line-3 {
  height: 1px;
  left: 210px;
  object-fit: cover;
  position: absolute;
  top: 65px;
  width: 898px;
}

.line-4 {
  height: 62px;
  left: 1261px;
  object-fit: cover;
  position: absolute;
  top: 4px;
  width: 1px;
}

.line-5 {
  height: 1px;
  left: 1109px;
  object-fit: cover;
  position: absolute;
  top: 17px;
  width: 224px;
}

.text-2 {
  left: 225px;
  letter-spacing: 0;
  line-height: 36px;
  position: absolute;
  text-align: center;
  top: 18px;
  white-space: nowrap;
}

.date {
  left: 1146px;
  letter-spacing: 0;
  line-height: 24px;
  position: absolute;
  text-align: center;
  top: 29px;
  white-space: nowrap;
}

.place {
  left: 1169px;
  letter-spacing: 0;
  line-height: 18px;
  position: absolute;
  text-align: center;
  top: 0;
  white-space: nowrap;
}

.cut {
  left: 1283px;
  letter-spacing: 0;
  line-height: 18px;
  position: absolute;
  text-align: center;
  top: 0;
  white-space: nowrap;
}

.number {
  left: 1286px;
  letter-spacing: 0;
  line-height: 24px;
  position: absolute;
  text-align: center;
  top: 29px;
  white-space: nowrap;
}

.title {
  color: var(--absolutewhite);
  font-family: var(--font-family-manrope);
  font-size: 36px;
  font-weight: 600;
  left: 25px;
  letter-spacing: 0;
  line-height: 54px;
  position: absolute;
  text-align: center;
  top: 38px;
  white-space: nowrap;
}

.text-3 {
  left: 225px;
  letter-spacing: 0;
  line-height: 36px;
  position: absolute;
  text-align: center;
  top: 79px;
  white-space: nowrap;
}

.indicators-container {
  align-items: center;
  display: flex;
  gap: 3px;
  height: 7px;
  justify-content: center;
  left: 1139px;
  position: absolute;
  top: 94px;
  width: 164px;
}

.shape-1 {
  background-color: var(--red45);
  border-radius: 100px;
  flex: 1;
  flex-grow: 1;
  height: 4px;
  position: relative;
}

.shape {
  background-color: var(--black20);
  border-radius: 100px;
  flex: 1;
  flex-grow: 1;
  height: 4px;
  position: relative;
}

.button-1 {
  align-items: center;
  background-color: var(--black06);
  border: 1px solid;
  border-color: #6d6565;
  border-radius: 6px;
  display: flex;
  gap: 4px;
  height: 60px;
  justify-content: center;
  margin-top: 32px;
  padding: 12px;
  position: relative;
  width: 836px;
}

.text-4 {
  letter-spacing: 0;
  line-height: 48px;
  margin-bottom: -5px;
  margin-top: -7px;
  position: relative;
  white-space: nowrap;
  width: fit-content;
}

.card-container {
  align-items: flex-start;
  display: flex;
  gap: 270px;
  margin-right: 22px;
  margin-top: 64px;
  min-width: 1192px;
}

.card {
  align-items: flex-start;
  background-color: var(--black06);
  border: 1px solid;
  border-color: var(--black15);
  border-radius: 12px;
  display: flex;
  flex-direction: column;
  gap: 20px;
  height: 608px;
  padding: 40px;
  position: relative;
  width: 461px;
}

.paragraph {
  align-self: stretch;
  color: var(--grey60);
  font-family: var(--font-family-roboto-semibold);
  font-size: var(--font-size-m);
  font-weight: 600;
  letter-spacing: 0;
  line-height: 35px;
  position: relative;
}

.card-1 {
  align-items: flex-start;
  background-color: var(--gray);
  border: 1px solid;
  border-radius: 12px;
  display: flex;
  flex-direction: column;
  gap: 20px;
  height: 608px;
  padding: 40px;
  position: relative;
  width: 461px;
}

.paragraph-1 {
  align-self: stretch;
  color: var(--absolutewhite);
  font-family: var(--font-family-roboto-semibold);
  font-size: var(--font-size-m);
  font-weight: 600;
  letter-spacing: 0;
  line-height: 35px;
  position: relative;
}

.button-2 {
  align-items: center;
  align-self: flex-end;
  background-color: var(--red45);
  border-radius: 6px;
  display: flex;
  gap: 10px;
  height: 43px;
  justify-content: center;
  margin-right: 81px;
  margin-top: 23px;
  padding: 14px 20px;
  position: relative;
  width: 189px;
}

.text-5 {
  color: var(--absolutewhite);
  font-family: var(--font-family-manrope-extralight);
  font-size: 25px;
  font-weight: 200;
  letter-spacing: 0;
  line-height: 37.5px;
  margin-bottom: -10.5px;
  margin-top: -12.5px;
  position: relative;
  text-align: center;
  white-space: nowrap;
  width: fit-content;
}
</style>
