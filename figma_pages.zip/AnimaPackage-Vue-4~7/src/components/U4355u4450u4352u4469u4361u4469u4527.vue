<template>
  <div class="container-center-horizontal">
    <div
      class="u4355u4450u4352u4469u4361u4469u4527-u4363u4455u4540u4370u4458-u4361u4453u4523u4368u4450u4520-u4363u4458u4523u4357u4461 screen"
    >
      <div class="overlap-group4">
        <div class="overlap-group6">
          <div class="overlap-group-container">
            <div class="overlap-group-1">
              <h1 class="title-2 inknutantiqua-normal-white-64px">{{ title }}</h1>
              <div class="button-8">
                <div class="text-6 inknutantiqua-normal-white-28px">{{ text }}</div>
              </div>
            </div>
            <div class="overlap-group3">
              <div class="items-container">
                <div class="faq-item-open">
                  <div class="text-container-1">
                    <div class="number-1 manrope-semi-bold-white-16px">{{ number }}</div>
                  </div>
                  <div class="text-container-2">
                    <div class="heading manrope-medium-white-20px">{{ heading }}</div>
                  </div>
                  <img
                    class="star"
                    src="https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e11c1bc6ae027f96f377c/img/star.svg"
                    alt="star"
                  />
                </div>
                <img
                  class="line"
                  src="https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e121e40ace40448c5fcab/img/line.svg"
                  alt="Line"
                />
                <faq-item :number="fAQItem1Props.number" :heading="fAQItem1Props.heading" />
                <img
                  class="line"
                  src="https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e121e40ace40448c5fcab/img/line-1.svg"
                  alt="Line"
                />
                <faq-item :number="fAQItem2Props.number" :heading="fAQItem2Props.heading" />
                <img
                  class="line"
                  src="https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e121e40ace40448c5fcab/img/line-2.svg"
                  alt="Line"
                />
                <faq-item :number="fAQItem3Props.number" :heading="fAQItem3Props.heading" />
              </div>
              <div class="cast-info valign-text-middle inknutantiqua-normal-white-32px">{{ castInfo }}</div>
            </div>
          </div>
          <img class="rectangle-15" :src="rectangle15" alt="Rectangle 15" />
          <div class="overlap-group2">
            <div class="text-5-1 valign-text-middle roboto-regular-normal-eerie-black-32px">{{ text5 }}</div>
            <div class="card-2">
              <div class="container-2">
                <div class="text-container-3">
                  <div class="name-1 manrope-medium-white-20px">{{ name }}</div>
                </div>
              </div>
              <p class="paragraph-2 roboto-regular-normal-mountain-mist-16px" v-html="paragraph"></p>
            </div>
          </div>
          <div class="overlap-group1-1">
            <img class="icon-media-play" :src="iconMediaPlay" alt="icon &#34;media play&#34;" /><x-button />
          </div>
        </div>
        <x-button :className="xButton1Props.className" />
      </div>
      <div class="button-container">
        <x-button4 :text="xButton41Props.text" />
        <x-button4 :text="xButton42Props.text" :className="xButton42Props.className" />
      </div>
    </div>
  </div>
</template>

<script>
import FAQItem from "./FAQItem";
import XButton from "./XButton";
import xButton from "./xButton";
import xButton4 from "./xButton4";
export default {
  name: "U4355u4450u4352u4469u4361u4469u4527",
  components: {
    FAQItem,
    XButton,
    xButton,
    xButton4,
  },
  props: [
    "title",
    "text",
    "number",
    "heading",
    "castInfo",
    "rectangle15",
    "text5",
    "name",
    "paragraph",
    "iconMediaPlay",
    "fAQItem1Props",
    "fAQItem2Props",
    "fAQItem3Props",
    "xButton1Props",
    "xButton41Props",
    "xButton42Props",
  ],
};
</script>

<style>
.u4355u4450u4352u4469u4361u4469u4527-u4363u4455u4540u4370u4458-u4361u4453u4523u4368u4450u4520-u4363u4458u4523u4357u4461 {
  align-items: flex-start;
  background-color: var(--eerie-black);
  display: flex;
  flex-direction: column;
  gap: 34px;
  height: 1024px;
  padding: 0 31px;
  width: 1440px;
}

.overlap-group4 {
  align-self: flex-end;
  height: 824px;
  margin-top: -1px;
  position: relative;
  width: 1359px;
}

.overlap-group6 {
  height: 824px;
  left: 44px;
  position: absolute;
  top: 0;
  width: 1315px;
}

.overlap-group-container {
  height: 824px;
  left: 369px;
  position: absolute;
  top: 0;
  width: 946px;
}

.overlap-group-1 {
  height: 230px;
  left: 0;
  position: absolute;
  top: 0;
  width: 595px;
}

.title-2 {
  left: 0;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  text-shadow: 0px 4px 4px #00000040;
  top: 0;
  width: 595px;
}

.button-8 {
  align-items: center;
  background-color: var(--black08);
  border: 1px solid;
  border-color: var(--black15);
  border-radius: 6px;
  display: flex;
  gap: 4px;
  height: 67px;
  justify-content: center;
  left: 69px;
  padding: 12px;
  position: absolute;
  top: 163px;
  width: 352px;
}

.text-6 {
  letter-spacing: 0;
  line-height: normal;
  margin-bottom: -13.5px;
  margin-top: -15.5px;
  position: relative;
  width: fit-content;
}

.overlap-group3 {
  height: 599px;
  left: 467px;
  position: absolute;
  top: 225px;
  width: 479px;
}

.items-container {
  align-items: flex-start;
  display: flex;
  flex-direction: column;
  left: 0;
  position: absolute;
  top: 71px;
  width: 479px;
}

.faq-item-open {
  align-items: center;
  align-self: stretch;
  display: flex;
  flex: 0 0 auto;
  gap: 16px;
  justify-content: center;
  padding: 24px;
  position: relative;
  width: 100%;
}

.text-container-1 {
  align-items: flex-start;
  background-color: var(--black12);
  border: 1px solid;
  border-color: var(--black15);
  border-radius: 8px;
  display: inline-flex;
  flex: 0 0 auto;
  flex-direction: column;
  gap: 10px;
  padding: 16px;
  position: relative;
}

.number-1 {
  letter-spacing: 0;
  line-height: normal;
  margin-top: -1px;
  position: relative;
  width: fit-content;
}

.text-container-2 {
  align-items: center;
  align-self: stretch;
  display: flex;
  flex: 1;
  flex-direction: column;
  flex-grow: 1;
  gap: 14px;
  justify-content: center;
  position: relative;
}

.heading {
  align-self: stretch;
  letter-spacing: 0;
  line-height: 30px;
  position: relative;
}

.star {
  height: 24px;
  position: relative;
  width: 24px;
}

.line {
  align-self: stretch;
  height: 1px;
  object-fit: cover;
  position: relative;
  width: 100%;
}

.cast-info {
  height: 83px;
  left: 160px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  top: 0;
}

.rectangle-15 {
  height: 530px;
  left: 0;
  object-fit: cover;
  position: absolute;
  top: 294px;
  width: 377px;
}

.overlap-group2 {
  border-radius: 12px;
  height: 530px;
  left: 437px;
  position: absolute;
  top: 294px;
  width: 377px;
}

.text-5-1 {
  height: 38px;
  left: 111px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  top: 14px;
  white-space: nowrap;
}

.card-2 {
  align-items: flex-start;
  background-color: var(--black06);
  border: 1px solid;
  border-color: var(--black15);
  border-radius: 12px;
  display: flex;
  flex-direction: column;
  gap: 20px;
  height: 530px;
  left: 0;
  padding: 40px;
  position: absolute;
  top: 0;
  width: 377px;
}

.container-2 {
  align-items: center;
  align-self: stretch;
  display: flex;
  flex: 0 0 auto;
  gap: 41px;
  position: relative;
  width: 100%;
}

.text-container-3 {
  align-items: flex-start;
  display: flex;
  flex: 1;
  flex-direction: column;
  flex-grow: 1;
  justify-content: center;
  position: relative;
}

.name-1 {
  align-self: stretch;
  letter-spacing: 0;
  line-height: 30px;
  margin-top: -1px;
  position: relative;
}

.paragraph-2 {
  align-self: stretch;
  letter-spacing: 0;
  line-height: normal;
  position: relative;
}

.overlap-group1-1 {
  height: 77px;
  left: 1020px;
  position: absolute;
  top: 38px;
  width: 294px;
}

.icon-media-play {
  height: 27px;
  left: 267px;
  position: absolute;
  top: 0;
  width: 27px;
}

.button-container {
  align-items: flex-start;
  display: flex;
  gap: 157px;
  height: 95px;
  margin-left: 109px;
  min-width: 717px;
  position: relative;
}
</style>
