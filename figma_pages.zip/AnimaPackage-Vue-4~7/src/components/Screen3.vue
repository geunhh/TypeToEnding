<template>
  <div class="container-center-horizontal">
    <div class="u4363u4455u4540u4370u4458-u4361u4453u4523u4368u4450u4520 screen">
      <div class="flex-row">
        <x-button />
        <h1 class="title-1 inknutantiqua-normal-white-96px">{{ title }}</h1>
      </div>
      <div class="flex-row-1">
        <img class="rectangle-14" :src="rectangle14" alt="Rectangle 14" /><img
          class="rectangle-12"
          :src="rectangle121"
          alt="Rectangle 12"
        /><img class="rectangle-11" :src="rectangle11" alt="Rectangle 11" /><img
          class="rectangle-12"
          :src="rectangle122"
          alt="Rectangle 12"
        /><img class="rectangle-13" :src="rectangle13" alt="Rectangle 13" />
      </div>
      <div class="flex-row-2">
        <x-button2 />
        <div class="button-3">
          <div class="create-room valign-text-middle">{{ createRoom }}</div>
        </div>
        <div class="group-3"><x-button2 :className="xButton2Props.className" /></div>
      </div>
    </div>
  </div>
</template>

<script>
import xButton from "./xButton";
import xButton2 from "./xButton2";
export default {
  name: "Screen3",
  components: {
    xButton,
    xButton2,
  },
  props: [
    "title",
    "rectangle14",
    "rectangle121",
    "rectangle11",
    "rectangle122",
    "rectangle13",
    "createRoom",
    "xButton2Props",
  ],
};
</script>

<style>
.u4363u4455u4540u4370u4458-u4361u4453u4523u4368u4450u4520 {
  align-items: flex-start;
  background-color: var(--eerie-black);
  display: flex;
  flex-direction: column;
  height: 1024px;
  width: 1440px;
}

.flex-row {
  align-items: center;
  display: flex;
  gap: 214px;
  height: 240px;
  margin-left: 50px;
  margin-top: -21px;
  min-width: 1174px;
  position: relative;
}

.title-1 {
  letter-spacing: 0;
  line-height: normal;
  min-height: 240px;
  text-shadow: 0px 4px 4px #00000040;
  width: 874px;
}

.flex-row-1 {
  align-items: flex-start;
  display: flex;
  gap: 48px;
  height: 568px;
  min-width: 1440px;
}

.rectangle-14 {
  height: 370px;
  object-fit: cover;
  width: 156px;
}

.rectangle-12 {
  align-self: center;
  height: 370px;
  margin-bottom: 86px;
  object-fit: cover;
  width: 269px;
}

.rectangle-11 {
  align-self: flex-end;
  height: 550px;
  object-fit: cover;
  width: 397px;
}

.rectangle-13 {
  height: 370px;
  object-fit: cover;
  width: 157px;
}

.flex-row-2 {
  align-items: flex-start;
  align-self: center;
  display: flex;
  gap: 32px;
  margin-top: 72px;
  min-width: 578px;
  position: relative;
}

.button-3 {
  align-items: flex-start;
  background-color: var(--gray);
  border-radius: 8px;
  display: flex;
  gap: 10px;
  padding: 18px 24px;
  position: relative;
  width: 388px;
}

.create-room {
  color: var(--absolutewhite);
  font-family: var(--font-family-malgun_gothic-semilight);
  font-size: 30px;
  font-weight: 400;
  height: 27px;
  letter-spacing: 0;
  line-height: 45px;
  margin-top: -1px;
  position: relative;
  text-align: center;
  white-space: nowrap;
  width: 340px;
}

.group-3 {
  align-items: flex-start;
  display: flex;
  height: 63px;
  min-width: 63px;
  position: relative;
  transform: rotate(180deg);
}
</style>
