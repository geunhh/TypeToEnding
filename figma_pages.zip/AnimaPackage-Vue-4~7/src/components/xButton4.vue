<template>
  <div :class="[`button-11`, className || ``]">
    <div class="text-9 valign-text-middle manrope-extra-light-white-32px">{{ text }}</div>
  </div>
</template>

<script>
export default {
  name: "xButton4",
  props: ["text", "className"],
};
</script>

<style>
.button-11 {
  align-items: center;
  background-color: var(--red45);
  border-radius: 6px;
  display: flex;
  gap: 10px;
  height: 63px;
  justify-content: center;
  padding: 14px 20px;
  position: relative;
  width: 280px;
}

.text-9 {
  letter-spacing: 0;
  line-height: 48px;
  margin-bottom: -5.5px;
  margin-top: -7.5px;
  position: relative;
  text-align: center;
  white-space: nowrap;
  width: fit-content;
}

.button-11.button-12 {
  align-self: flex-end;
}

.button-11.button-14 {
  align-self: flex-end;
  background-color: var(--gray);
}
</style>
