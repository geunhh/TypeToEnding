<template>
  <div class="faq-item">
    <div class="text-container-4">
      <div class="number-2 manrope-semi-bold-white-16px">{{ number }}</div>
    </div>
    <div class="heading-1 manrope-medium-white-20px">{{ heading }}</div>
    <img
      class="icon"
      src="https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e11c1bc6ae027f96f377c/img/icon-1.svg"
      alt="Icon"
    />
  </div>
</template>

<script>
export default {
  name: "FAQItem",
  props: ["number", "heading"],
};
</script>

<style>
.faq-item,
.faq-item-1 {
  align-items: center;
  align-self: stretch;
  display: flex;
  flex: 0 0 auto;
  gap: 16px;
  padding: 24px;
  position: relative;
  width: 100%;
}

.text-container-4,
.text-container-5 {
  align-items: flex-start;
  background-color: var(--black12);
  border: 1px solid;
  border-color: var(--black15);
  border-radius: 8px;
  display: inline-flex;
  flex: 0 0 auto;
  flex-direction: column;
  gap: 10px;
  padding: 16px;
  position: relative;
}

.number-2,
.number-3 {
  letter-spacing: 0;
  line-height: normal;
  margin-top: -1px;
  position: relative;
  width: fit-content;
}

.heading-1,
.heading-2 {
  flex: 1;
  letter-spacing: 0;
  line-height: 30px;
  position: relative;
}

.icon,
.icon-1 {
  height: 24px;
  position: relative;
  width: 24px;
}
</style>
