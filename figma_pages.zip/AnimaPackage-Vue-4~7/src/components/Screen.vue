<template>
  <div class="container-center-horizontal">
    <div
      class="u4369u4455u4540u4352u4449u4352u4449-u4353u4467u4544u4354u4449u4539u4361u4467u4536u4354u4469u4355u4449 screen"
    >
      <h1 class="text-1 valign-text-middle inknutantiqua-normal-white-96px">{{ text1 }}</h1>
      <div class="container">
        <div class="button">
          <div class="text valign-text-middle">{{ text }}</div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "Screen",
  props: ["text1", "text"],
};
</script>

<style>
.u4369u4455u4540u4352u4449u4352u4449-u4353u4467u4544u4354u4449u4539u4361u4467u4536u4354u4469u4355u4449 {
  align-items: flex-start;
  background-color: var(--eerie-black);
  display: flex;
  flex-direction: column;
  gap: 112px;
  height: 1024px;
  padding: 263px 336px;
  width: 1440px;
}

.text-1 {
  height: 248px;
  letter-spacing: 0;
  line-height: normal;
  min-width: 767px;
  text-align: center;
  text-shadow: 0px 4px 4px #00000040;
}

.container {
  align-items: center;
  align-self: center;
  display: flex;
  gap: 70px;
  margin-right: 18px;
  position: relative;
  width: 388px;
}

.button {
  align-items: flex-start;
  background-color: var(--red45);
  border-radius: 8px;
  display: flex;
  gap: 10px;
  padding: 18px 24px;
  position: relative;
  width: 388px;
}

.text {
  color: var(--absolutewhite);
  font-family: var(--font-family-manrope);
  font-size: 30px;
  font-weight: 600;
  height: 27px;
  letter-spacing: 0;
  line-height: 45px;
  margin-top: -1px;
  position: relative;
  text-align: center;
  white-space: nowrap;
  width: 340px;
}
</style>
