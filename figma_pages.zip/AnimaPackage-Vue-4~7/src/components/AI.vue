<template>
  <div class="container-center-horizontal">
    <div class="aiu4352u4449-u4369u4455u4540u4352u4449u4364u4462u4540u4363u4469u4536u4354u4469u4355u4449 screen">
      <h1 class="ai valign-text-middle inknutantiqua-normal-white-96px" v-html="ai"></h1>
    </div>
  </div>
</template>

<script>
export default {
  name: "AI",
  props: ["ai"],
};
</script>

<style>
.aiu4352u4449-u4369u4455u4540u4352u4449u4364u4462u4540u4363u4469u4536u4354u4469u4355u4449 {
  align-items: flex-start;
  background-color: var(--eerie-black);
  display: flex;
  height: 1024px;
  padding: 263px 219px;
  width: 1440px;
}

.ai {
  height: 496px;
  letter-spacing: 0;
  line-height: normal;
  margin-left: 1px;
  min-width: 1001px;
  text-align: center;
  text-shadow: 0px 4px 4px #00000040;
}
</style>
