<template>
  <div class="container-1">
    <div class="text-container">
      <div class="name manrope-medium-white-20px">{{ name }}</div>
    </div>
  </div>
</template>

<script>
export default {
  name: "Container",
  props: ["name"],
};
</script>

<style>
.container-1 {
  align-items: center;
  align-self: stretch;
  display: flex;
  flex: 0 0 auto;
  gap: 41px;
  position: relative;
  width: 100%;
}

.text-container {
  align-items: flex-start;
  display: flex;
  flex: 1;
  flex-direction: column;
  flex-grow: 1;
  justify-content: center;
  position: relative;
}

.name {
  align-self: stretch;
  letter-spacing: 0;
  line-height: 30px;
  margin-top: -1px;
  position: relative;
}
</style>
