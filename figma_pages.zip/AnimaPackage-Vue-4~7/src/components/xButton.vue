<template>
  <div class="button-9">
    <img
      class="icon-2"
      src="https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e06dfdc93edb558965c7e/img/icon.svg"
      alt="Icon"
    />
    <div class="text-7 valign-text-middle manrope-semi-bold-white-32px">How to play</div>
  </div>
</template>

<script>
export default {
  name: "XButton",
};
</script>

<style>
.button-9,
.button-10 {
  align-items: center;
  background-color: var(--red45);
  border-radius: 8px;
  display: flex;
  gap: 4px;
  height: 63px;
  left: 0;
  padding: 18px 24px;
  position: absolute;
  top: 14px;
  width: 280px;
}

.icon-2,
.icon-3 {
  height: 28px;
  margin-bottom: -0.5px;
  margin-top: -0.5px;
  position: relative;
  width: 28px;
}

.text-7,
.text-8 {
  height: 63px;
  letter-spacing: 0;
  line-height: 48px;
  margin-bottom: -17px;
  margin-right: -3px;
  margin-top: -19px;
  position: relative;
  text-align: center;
  width: 203px;
}
</style>
