<template>
  <div class="container-center-horizontal">
    <div
      class="u4366u4453u4538u4359u4453u4523u4365u4450-u4361u4469u4354u4449u4357u4469u4363u4457u4352u4449-u4363u4457u4352u4457-u4363u4469u4539u4361u4467u4536u4354u4469u4355u4449 screen"
    >
      <h1 class="text-4-1 valign-text-middle inknutantiqua-normal-white-96px" v-html="text4"></h1>
    </div>
  </div>
</template>

<script>
export default {
  name: "Screen2",
  props: ["text4"],
};
</script>

<style>
.u4366u4453u4538u4359u4453u4523u4365u4450-u4361u4469u4354u4449u4357u4469u4363u4457u4352u4449-u4363u4457u4352u4457-u4363u4469u4539u4361u4467u4536u4354u4469u4355u4449 {
  align-items: flex-start;
  background-color: var(--eerie-black);
  display: flex;
  height: 1024px;
  padding: 263px 339px;
  width: 1440px;
}

.text-4-1 {
  height: 496px;
  letter-spacing: 0;
  line-height: normal;
  margin-left: 1px;
  min-width: 761px;
  text-align: center;
  text-shadow: 0px 4px 4px #00000040;
}
</style>
