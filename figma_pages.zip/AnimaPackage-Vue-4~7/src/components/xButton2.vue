<template>
  <div :class="[`button-7-1`, className || ``]">
    <div class="group-1"></div>
  </div>
</template>

<script>
export default {
  name: "xButton2",
  props: ["className"],
};
</script>

<style>
.button-7-1 {
  align-items: center;
  background-color: var(--red45);
  border: 1px solid;
  border-color: var(--black12);
  border-radius: 6px;
  display: flex;
  gap: 10px;
  height: 63px;
  justify-content: center;
  padding: 10px;
  position: relative;
  width: 63px;
}

.group-1 {
  background-image: url(https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e12a3708a294a09fd687d/img/play-arrow-filled.svg);
  background-size: 100% 100%;
  height: 63px;
  margin-bottom: -10px;
  margin-left: -10px;
  margin-right: -10px;
  margin-top: -10px;
  position: relative;
  width: 63px;
}

.button-7-1.button-7 .group-1 {
  background-image: url(https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e12a3708a294a09fd687d/img/play-arrow-filled-1.svg);
}
</style>
