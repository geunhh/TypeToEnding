<template>
  <div class="container-center-horizontal">
    <div
      class="u4355u4450u4352u4469u4361u4469u4527-u4363u4455u4540u4370u4458-u4361u4453u4523u4368u4450u4520-u4364u4453u4523 screen"
    >
      <div class="overlap-group5">
        <div class="overlap-group-container-1">
          <div class="overlap-group-container-2">
            <div class="overlap-group4-1">
              <h1 class="title-3 inknutantiqua-normal-white-64px">{{ title }}</h1>
              <div class="button-15">
                <div class="text-11 inknutantiqua-normal-white-28px">{{ text }}</div>
              </div>
            </div>
            <div class="overlap-group2-1">
              <div class="items-container-1">
                <div class="faq-item-open-1">
                  <div class="text-container-6">
                    <div class="number-4 manrope-semi-bold-white-16px">{{ number }}</div>
                  </div>
                  <div class="text-container-7">
                    <div class="heading-3 manrope-medium-white-20px">{{ heading }}</div>
                  </div>
                  <img
                    class="star-1"
                    src="https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e11c1bc6ae027f96f377c/img/star.svg"
                    alt="star"
                  />
                </div>
                <img
                  class="line-6"
                  src="https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e11c1bc6ae027f96f377c/img/line.svg"
                  alt="Line"
                />
                <faq-item :number="fAQItem1Props.number" :heading="fAQItem1Props.heading" />
                <img
                  class="line-6"
                  src="https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e11c1bc6ae027f96f377c/img/line-1.svg"
                  alt="Line"
                />
                <faq-item :number="fAQItem2Props.number" :heading="fAQItem2Props.heading" />
                <img
                  class="line-6"
                  src="https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e11c1bc6ae027f96f377c/img/line-2.svg"
                  alt="Line"
                />
                <faq-item :number="fAQItem3Props.number" :heading="fAQItem3Props.heading" />
              </div>
              <div class="cast-info-1 valign-text-middle inknutantiqua-normal-white-32px">{{ castInfo }}</div>
            </div>
          </div>
          <div class="overlap-group-2">
            <div class="text-6-1 valign-text-middle">{{ text6 }}</div>
          </div>
          <div class="overlap-group3-1">
            <div class="text-7-1 valign-text-middle roboto-regular-normal-eerie-black-32px">{{ text7 }}</div>
            <div class="card-3">
              <div class="container-3">
                <div class="text-container-8">
                  <div class="name-2 manrope-medium-white-20px">{{ name }}</div>
                </div>
              </div>
              <div class="paragraph-3 roboto-regular-normal-mountain-mist-16px">{{ paragraph }}</div>
            </div>
          </div>
          <div class="overlap-group1-2">
            <img class="icon-media-play-1" :src="iconMediaPlay" alt="icon &#34;media play&#34;" /><x-button />
          </div>
        </div>
        <x-button :className="xButton1Props.className" />
      </div>
      <div class="button-container-1">
        <x-button4 :text="xButton41Props.text" />
        <x-button4 :text="xButton42Props.text" :className="xButton42Props.className" />
      </div>
    </div>
  </div>
</template>

<script>
import FAQItem from "./FAQItem";
import XButton from "./XButton";
import xButton from "./xButton";
import xButton4 from "./xButton4";
export default {
  name: "U4355u4450u4352u4469u4361u4469u45272",
  components: {
    FAQItem,
    XButton,
    xButton,
    xButton4,
  },
  props: [
    "title",
    "text",
    "number",
    "heading",
    "castInfo",
    "text6",
    "text7",
    "name",
    "paragraph",
    "iconMediaPlay",
    "fAQItem1Props",
    "fAQItem2Props",
    "fAQItem3Props",
    "xButton1Props",
    "xButton41Props",
    "xButton42Props",
  ],
};
</script>

<style>
.u4355u4450u4352u4469u4361u4469u4527-u4363u4455u4540u4370u4458-u4361u4453u4523u4368u4450u4520-u4364u4453u4523 {
  align-items: flex-start;
  background-color: var(--eerie-black);
  display: flex;
  flex-direction: column;
  gap: 34px;
  height: 1024px;
  padding: 0 31px;
  width: 1440px;
}

.overlap-group5 {
  align-self: flex-end;
  height: 824px;
  margin-top: -1px;
  position: relative;
  width: 1359px;
}

.overlap-group-container-1 {
  height: 824px;
  left: 44px;
  position: absolute;
  top: 0;
  width: 1315px;
}

.overlap-group-container-2 {
  height: 824px;
  left: 369px;
  position: absolute;
  top: 0;
  width: 946px;
}

.overlap-group4-1 {
  height: 230px;
  left: 0;
  position: absolute;
  top: 0;
  width: 595px;
}

.title-3 {
  left: 0;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  text-shadow: 0px 4px 4px #00000040;
  top: 0;
  width: 595px;
}

.button-15 {
  align-items: center;
  background-color: var(--black08);
  border: 1px solid;
  border-color: var(--black15);
  border-radius: 6px;
  display: flex;
  gap: 4px;
  height: 67px;
  justify-content: center;
  left: 69px;
  padding: 12px;
  position: absolute;
  top: 163px;
  width: 352px;
}

.text-11 {
  letter-spacing: 0;
  line-height: normal;
  margin-bottom: -13.5px;
  margin-top: -15.5px;
  position: relative;
  width: fit-content;
}

.overlap-group2-1 {
  height: 599px;
  left: 467px;
  position: absolute;
  top: 225px;
  width: 479px;
}

.items-container-1 {
  align-items: flex-start;
  display: flex;
  flex-direction: column;
  left: 0;
  position: absolute;
  top: 71px;
  width: 479px;
}

.faq-item-open-1 {
  align-items: center;
  align-self: stretch;
  display: flex;
  flex: 0 0 auto;
  gap: 16px;
  justify-content: center;
  padding: 24px;
  position: relative;
  width: 100%;
}

.text-container-6 {
  align-items: flex-start;
  background-color: var(--black12);
  border: 1px solid;
  border-color: var(--black15);
  border-radius: 8px;
  display: inline-flex;
  flex: 0 0 auto;
  flex-direction: column;
  gap: 10px;
  padding: 16px;
  position: relative;
}

.number-4 {
  letter-spacing: 0;
  line-height: normal;
  margin-top: -1px;
  position: relative;
  width: fit-content;
}

.text-container-7 {
  align-items: center;
  align-self: stretch;
  display: flex;
  flex: 1;
  flex-direction: column;
  flex-grow: 1;
  gap: 14px;
  justify-content: center;
  position: relative;
}

.heading-3 {
  align-self: stretch;
  letter-spacing: 0;
  line-height: 30px;
  position: relative;
}

.star-1 {
  height: 24px;
  position: relative;
  width: 24px;
}

.line-6 {
  align-self: stretch;
  height: 1px;
  object-fit: cover;
  position: relative;
  width: 100%;
}

.cast-info-1 {
  height: 83px;
  left: 160px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  top: 0;
}

.overlap-group-2 {
  align-items: flex-end;
  background-color: #0f0f0f33;
  border-radius: 12px;
  display: flex;
  height: 530px;
  justify-content: flex-end;
  left: 0;
  min-width: 377px;
  padding: 240px 51px;
  position: absolute;
  top: 294px;
}

.text-6-1 {
  color: #ffffff96;
  font-family: var(--font-family-manrope);
  font-size: 30px;
  font-weight: 600;
  height: 45px;
  letter-spacing: 0;
  line-height: 45px;
  min-width: 263px;
  text-align: center;
  white-space: nowrap;
}

.overlap-group3-1 {
  border-radius: 12px;
  height: 530px;
  left: 437px;
  position: absolute;
  top: 294px;
  width: 377px;
}

.text-7-1 {
  height: 38px;
  left: 111px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  top: 14px;
  white-space: nowrap;
}

.card-3 {
  align-items: flex-start;
  background-color: var(--black06);
  border: 1px solid;
  border-color: var(--black15);
  border-radius: 12px;
  display: flex;
  flex-direction: column;
  gap: 20px;
  height: 530px;
  left: 0;
  padding: 40px;
  position: absolute;
  top: 0;
  width: 377px;
}

.container-3 {
  align-items: center;
  align-self: stretch;
  display: flex;
  flex: 0 0 auto;
  gap: 41px;
  position: relative;
  width: 100%;
}

.text-container-8 {
  align-items: flex-start;
  display: flex;
  flex: 1;
  flex-direction: column;
  flex-grow: 1;
  justify-content: center;
  position: relative;
}

.name-2 {
  align-self: stretch;
  letter-spacing: 0;
  line-height: 30px;
  margin-top: -1px;
  position: relative;
}

.paragraph-3 {
  align-self: stretch;
  letter-spacing: 0;
  line-height: normal;
  position: relative;
}

.overlap-group1-2 {
  height: 77px;
  left: 1020px;
  position: absolute;
  top: 38px;
  width: 294px;
}

.icon-media-play-1 {
  height: 27px;
  left: 267px;
  position: absolute;
  top: 0;
  width: 27px;
}

.button-container-1 {
  align-items: flex-start;
  display: flex;
  gap: 157px;
  height: 95px;
  margin-left: 109px;
  min-width: 717px;
  position: relative;
}
</style>
