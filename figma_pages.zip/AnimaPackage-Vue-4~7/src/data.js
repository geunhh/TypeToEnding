export const container1Data = {
    name: "시나리오 설명",
};

export const container2Data = {
    name: "당신의 대답은??",
};

export const x1Data = {
    text2: "영화 : 파묘",
    date: "2024.11.07",
    place: "DATE",
    cut: "CUT",
    number: "39",
    title: "S# 12f",
    text3: "감독 : 김근휘",
    text1: "주어진 상황에 이어질 시나리오를 작성하시오",
    paragraph1: "주인공 강 박사는 자신의 조상 묘를 옮기기로 결심하고, <br />새로운 장소로 이장하는 과정에서 주변 인물들이 알 수 <br />없는 사고와 불행에 휘말리게 됩니다. <br />조상의 묘를 파는 과정에서 주인공은 조상의 묘가 첩장이 되어있다는 사실을 알게 되었습니다. 당신은 이 상황에서 어떻게 하실건가요?",
    paragraph2: "몰라여<br />머 어떻게든 되겠죠 ㅎ",
    text4: "시나리오 제출",
    container1Props: container1Data,
    container2Props: container2Data,
};

export const xButton22Data = {
    className: "button-7",
};

export const screen3Data = {
    title: "Type to Ending",
    rectangle14: "https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e12a3708a294a09fd687d/img/rectangle-14@2x.png",
    rectangle121: "https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e12a3708a294a09fd687d/img/rectangle-12-1@2x.png",
    rectangle11: "https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e12a3708a294a09fd687d/img/rectangle-11.png",
    rectangle122: "https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e12a3708a294a09fd687d/img/rectangle-12@2x.png",
    rectangle13: "https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e12a3708a294a09fd687d/img/rectangle-13@2x.png",
    createRoom: "선택 완료",
    xButton2Props: xButton22Data,
};

export const fAQItem1Data = {
    number: "02",
    heading: "마왕에게 납치되어 타락한 히로인",
};

export const fAQItem2Data = {
    number: "03",
    heading: "모든 일의 원흉이었던 파트너",
};

export const fAQItem3Data = {
    number: "04",
    heading: "개과천선한 마왕군 간부",
};

export const xButton4Data = {
    className: "button-5",
};

export const xButton42Data = {
    text: "영화 변경",
};

export const xButton43Data = {
    text: "게임 시작",
    className: "button-12",
};

export const u4355u4450u4352u4469u4361u4469u4527Data = {
    title: "Type to Ending",
    text: "Theater code : 3F7D",
    number: "01",
    heading: "엔딩 직전까지 고통받는 주인공",
    castInfo: "Cast Info",
    rectangle15: "https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e121e40ace40448c5fcab/img/rectangle-15.png",
    text5: "영화 줄거리",
    name: "영화 줄거리",
    paragraph: "영화 파묘는 1976년 개봉한 한국 영화로, 김기영 감독이 연출한 심리 스릴러입니다.<br /><br />이 영화는 한 가족이 묘를 이장하면서 겪는 기이한 사건들을 중심으로 전개됩니다.<br /><br />주인공 강 박사는 자신의 조상 묘를 옮기기로 결심하고, 새로운 장소로 이장하는 과정에서 주변 인물들이 알 수 없는 사고와 불행에 휘말리게 됩니다. <br />영화는 가족의 운명을 뒤흔드는 저주와 유령의 존재를 다루며, 미스터리하고 긴장감 넘치는 분위기를 만들어냅니다. 특히 김기영 감독 특유의 독특한 연출 기법과 상징적인 장면들이 돋보이며, 강렬한 심리적 공포를 전달합니다.<br />이 영화는 가족과 조상에 대한 신념과 불안, 그리고 미신에 대한 한국적 정서를 탐구하며, 사회적 금기에 도전하는 작품으로 평가받고 있습니다.",
    iconMediaPlay: "https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673df1608bbac2c0338db9f5/img/---icon--media-play-@2x.png",
    fAQItem1Props: fAQItem1Data,
    fAQItem2Props: fAQItem2Data,
    fAQItem3Props: fAQItem3Data,
    xButton1Props: xButton4Data,
    xButton41Props: xButton42Data,
    xButton42Props: xButton43Data,
};

export const fAQItem4Data = {
    number: "02",
    heading: "마왕에게 납치되어 타락한 히로인",
};

export const fAQItem5Data = {
    number: "03",
    heading: "모든 일의 원흉이었던 파트너",
};

export const fAQItem6Data = {
    number: "04",
    heading: "개과천선한 마왕군 간부",
};

export const xButton6Data = {
    className: "button-6",
};

export const xButton44Data = {
    text: "영화 변경",
};

export const xButton45Data = {
    text: "게임 시작",
    className: "button-14",
};

export const u4355u4450u4352u4469u4361u4469u45272Data = {
    title: "Type to Ending",
    text: "Theater code : 3F7D",
    number: "01",
    heading: "엔딩 직전까지 고통받는 주인공",
    castInfo: "Cast Info",
    text6: "영화를 선택해주세요.",
    text7: "영화 줄거리",
    name: "영화 줄거리",
    paragraph: "먼저 영화를 선택해 주세요",
    iconMediaPlay: "https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673df1608bbac2c0338db9f5/img/---icon--media-play-@2x.png",
    fAQItem1Props: fAQItem4Data,
    fAQItem2Props: fAQItem5Data,
    fAQItem3Props: fAQItem6Data,
    xButton1Props: xButton6Data,
    xButton41Props: xButton44Data,
    xButton42Props: xButton45Data,
};

