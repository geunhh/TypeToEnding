export const subContainer1Data = {
    heading: "Nickname",
};

export const subContainer2Data = {
    heading: "Age",
};

export const subContainer3Data = {
    heading: "Sex",
};

export const subContainer4Data = {
    heading: "Email",
};

export const container1Data = {
    text: "Change Password",
};

export const container2Data = {
    text: "Profile Update",
};

export const screenData = {
    heading1: "근흐흐’s Profile Page",
    text: "근흐흐",
    text2: "26",
    text3: "Male",
    text4: "Geunhh@example.com",
    heading2: "Win rate",
    heading3: "9W 1L",
    text5: "4.5",
    text1: "전적보기",
    subContainer1Props: subContainer1Data,
    subContainer2Props: subContainer2Data,
    subContainer3Props: subContainer3Data,
    subContainer4Props: subContainer4Data,
    container1Props: container1Data,
    container2Props: container2Data,
};

export const container22Data = {
    text: "Profile",
};

export const container23Data = {
    text: "Create Room",
};

export const container24Data = {
    text: "Enter Room",
};

export const container25Data = {
    text: "Sign Out",
    className: "container-7",
};

export const xMainData = {
    id: "ID",
    pw: "PW",
    rememberMe: "remember me",
    title: "Type to Ending",
    iconMediaPlay: "https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673df1608bbac2c0338db9f5/img/---icon--media-play-@2x.png",
    text1: "How to play",
    heading: "영화관 코드를 입력해주세요",
    text2: "3F7D",
    text3: "확인",
    container1Props: container22Data,
    container2Props: container23Data,
    container3Props: container24Data,
    container4Props: container25Data,
};

