import Vue from "vue";
import Router from "vue-router";
import Screen from "./components/Screen";
import XMain from "./components/XMain";
import { screenData, xMainData } from "./data";

Vue.use(Router);

export default new Router({
  mode: "history",
  routes: [
    {
      path: "/u4369u4467u4357u4457u4369u4469u4527-u4369u4454u4363u4469u4364u4469",
      component: Screen,
      props: { ...screenData },
    },
    {
      path: "*",
      component: XMain,
      props: { ...xMainData },
    },
  ],
});
