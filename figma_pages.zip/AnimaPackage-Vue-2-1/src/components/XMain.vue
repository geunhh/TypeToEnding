<template>
  <div class="container-center-horizontal">
    <div class="main-u4359u4449u4540u4363u4454-u4366u4449u4535u4352u4449u4370u4449u4352u4469 screen">
      <div class="overlap-group-1">
        <div class="id">{{ id }}</div>
        <div class="pw">{{ pw }}</div>
        <div class="remember-me">{{ rememberMe }}</div>
        <h1 class="title">{{ title }}</h1>
        <img class="icon-media-play" :src="iconMediaPlay" alt="icon &#34;media play&#34;" />
        <div class="button-3">
          <img
            class="icon-1"
            src="https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e07b140ace40448c5fc73/img/icon.svg"
            alt="Icon"
          />
          <div class="text-3 valign-text-middle">{{ text1 }}</div>
        </div>
        <div class="form">
          <container2 :text="container1Props.text" />
          <container2 :text="container2Props.text" />
          <container2 :text="container3Props.text" />
          <div class="dummy">
            <div class="button-4"></div>
          </div>
          <container2 :text="container4Props.text" :className="container4Props.className" />
        </div>
        <img
          class="generic-avatar"
          src="https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e06dfdc93edb558965c7e/img/generic-avatar.svg"
          alt="Generic avatar"
        />
        <img
          class="add_circle"
          src="https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e06dfdc93edb558965c7e/img/add-circle.svg"
          alt="add_circle"
        />
        <img
          class="forward"
          src="https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e06dfdc93edb558965c7e/img/forward.svg"
          alt="forward"
        />
        <div class="rectangle-518"></div>
        <div class="card">
          <div class="text-container">
            <div class="heading-4 valign-text-middle">{{ heading }}</div>
          </div>
          <div class="buttons-container">
            <div class="button-5">
              <div class="text-4 valign-text-middle">{{ text2 }}</div>
            </div>
            <div class="button-6">
              <div class="text-5">{{ text3 }}</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import Container2 from "./Container2";
export default {
  name: "XMain",
  components: {
    Container2,
  },
  props: [
    "id",
    "pw",
    "rememberMe",
    "title",
    "iconMediaPlay",
    "text1",
    "heading",
    "text2",
    "text3",
    "container1Props",
    "container2Props",
    "container3Props",
    "container4Props",
  ],
};
</script>

<style>
.main-u4359u4449u4540u4363u4454-u4366u4449u4535u4352u4449u4370u4449u4352u4469 {
  align-items: flex-start;
  background-color: var(--black10);
  display: flex;
  width: 1440px;
}

.overlap-group-1 {
  height: 1024px;
  position: relative;
  width: 1440px;
}

.id {
  color: var(--black10);
  font-family: var(--font-family-inter-regular);
  font-size: 36px;
  font-weight: 400;
  left: 90px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  top: 541px;
}

.pw {
  color: var(--black10);
  font-family: var(--font-family-inter-regular);
  font-size: var(--font-size-xl);
  font-weight: 400;
  left: 90px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  top: 615px;
  width: 60px;
}

.remember-me {
  color: var(--black10);
  font-family: var(--font-family-inter-regular);
  font-size: var(--font-size-xxs);
  font-weight: 400;
  left: 104px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  top: 680px;
}

.title {
  color: var(--absolutewhite);
  font-family: var(--font-family-inknut_antiqua-regular);
  font-size: var(--font-size-xxl);
  font-weight: 400;
  left: 312px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  text-shadow: 0px 4px 4px #00000040;
  top: 116px;
}

.icon-media-play {
  height: 27px;
  left: 1336px;
  position: absolute;
  top: 452px;
  width: 27px;
}

.button-3 {
  align-items: center;
  background-color: var(--red45);
  border-radius: 8px;
  display: flex;
  gap: 4px;
  height: 63px;
  left: 1083px;
  padding: 18px 24px;
  position: absolute;
  top: 471px;
  width: 280px;
}

.icon-1 {
  height: 28px;
  margin-bottom: -0.5px;
  margin-top: -0.5px;
  position: relative;
  width: 28px;
}

.text-3 {
  color: var(--absolutewhite);
  font-family: var(--font-family-manrope);
  font-size: var(--font-size-xl);
  font-weight: 600;
  height: 63px;
  letter-spacing: 0;
  line-height: 48px;
  margin-bottom: -17px;
  margin-right: -3px;
  margin-top: -19px;
  position: relative;
  text-align: center;
  width: 203px;
}

.form {
  align-items: flex-start;
  background-color: var(--black06);
  border: 1px solid;
  border-color: var(--black15);
  border-radius: 12px;
  display: flex;
  flex-direction: column;
  gap: 50px;
  height: 621px;
  left: 52px;
  padding: 50px;
  position: absolute;
  top: 374px;
  width: 488px;
}

.dummy {
  align-items: center;
  align-self: stretch;
  display: flex;
  flex: 0 0 auto;
  gap: 70px;
  position: relative;
  width: 100%;
}

.button-4 {
  border-radius: 8px;
  position: relative;
  width: 388px;
}

.generic-avatar {
  height: 45px;
  left: 127px;
  position: absolute;
  top: 433px;
  width: 45px;
}

.add_circle {
  height: 45px;
  left: 127px;
  position: absolute;
  top: 547px;
  width: 45px;
}

.forward {
  height: 45px;
  left: 127px;
  position: absolute;
  top: 660px;
  width: 45px;
}

.rectangle-518 {
  background-color: #d9d9d980;
  height: 1024px;
  left: 0;
  position: absolute;
  top: 0;
  width: 1440px;
}

.card {
  align-items: flex-start;
  background-color: var(--black10);
  border: 1px solid;
  border-color: var(--black15);
  border-radius: 12px;
  display: flex;
  flex-direction: column;
  gap: 50px;
  left: 466px;
  padding: 50px;
  position: absolute;
  top: 158px;
  width: 512px;
}

.text-container {
  align-items: flex-start;
  align-self: stretch;
  display: flex;
  flex: 0 0 auto;
  flex-direction: column;
  gap: 16px;
  position: relative;
  width: 100%;
}

.heading-4 {
  align-self: stretch;
  color: var(--absolutewhite);
  font-family: var(--font-family-manrope-bold);
  font-size: var(--font-size-l);
  font-weight: 700;
  letter-spacing: 0;
  line-height: 36px;
  margin-top: -1px;
  position: relative;
  text-align: center;
}

.buttons-container {
  align-items: flex-start;
  align-self: stretch;
  display: flex;
  flex: 0 0 auto;
  gap: 20px;
  position: relative;
  width: 100%;
}

.button-5 {
  align-items: center;
  background-color: var(--black08);
  border: 1px solid;
  border-color: var(--black15);
  border-radius: 8px;
  display: flex;
  gap: 10px;
  height: 59px;
  justify-content: center;
  padding: 0px 24px;
  position: relative;
  width: 328px;
}

.text-4 {
  color: var(--absolutewhite);
  font-family: var(--font-family-manrope);
  font-size: 40px;
  font-weight: 600;
  height: 60px;
  letter-spacing: 0;
  line-height: 60px;
  margin-left: -23.5px;
  margin-right: -23.5px;
  margin-top: -1.5px;
  position: relative;
  text-align: center;
  white-space: nowrap;
  width: 327px;
}

.button-6 {
  align-items: center;
  background-color: var(--red45);
  border-radius: 8px;
  display: flex;
  flex: 1;
  flex-grow: 1;
  gap: 10px;
  justify-content: center;
  padding: 18px 24px;
  position: relative;
}

.text-5 {
  color: var(--absolutewhite);
  font-family: var(--font-family-manrope);
  font-size: 15px;
  font-weight: 600;
  letter-spacing: 0;
  line-height: 22.5px;
  margin-left: -6px;
  margin-right: -6px;
  margin-top: -1px;
  position: relative;
  white-space: nowrap;
  width: fit-content;
}
</style>
