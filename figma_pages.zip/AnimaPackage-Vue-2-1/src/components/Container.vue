<template>
  <div class="container-6">
    <div class="button-2">
      <div class="text-2 manrope-semi-bold-white-18px">{{ text }}</div>
    </div>
  </div>
</template>

<script>
export default {
  name: "Container",
  props: ["text"],
};
</script>

<style>
.container-6 {
  align-items: center;
  align-self: stretch;
  display: flex;
  flex: 0 0 auto;
  gap: 70px;
  position: relative;
  width: 100%;
}

.button-2 {
  align-items: flex-start;
  background-color: var(--red45);
  border-radius: 8px;
  display: flex;
  gap: 10px;
  padding: 18px 24px;
  position: relative;
  width: 336px;
}

.text-2 {
  height: 27px;
  letter-spacing: 0;
  line-height: 27px;
  margin-top: -1px;
  position: relative;
  text-align: center;
  white-space: nowrap;
  width: 284px;
}
</style>
