<template>
  <div class="container-center-horizontal">
    <div class="u4369u4467u4357u4457u4369u4469u4527-u4369u4454u4363u4469u4364u4469 screen">
      <div class="button">
        <img
          class="skip_previous_filled"
          src="https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e0c07d5daf93032272fb1/img/skip-previous-filled.svg"
          alt="skip_previous_filled"
        />
      </div>
      <div class="overlap-group">
        <div class="sub-container-1">
          <div class="container">
            <div class="sub-container-2">
              <h1 class="heading valign-text-middle">{{ heading1 }}</h1>
            </div>
          </div>
          <div class="container">
            <sub-container :heading="subContainer1Props.heading" />
            <div class="sub-container">
              <div class="container-1">
                <div class="text manrope-medium-white-14px">{{ text }}</div>
              </div>
            </div>
          </div>
          <div class="container">
            <sub-container :heading="subContainer2Props.heading" />
            <div class="sub-container">
              <div class="container-1">
                <div class="text manrope-medium-white-14px">{{ text2 }}</div>
              </div>
            </div>
          </div>
          <div class="container">
            <sub-container :heading="subContainer3Props.heading" />
            <div class="sub-container">
              <div class="container-1">
                <div class="text manrope-medium-white-14px">{{ text3 }}</div>
              </div>
            </div>
          </div>
          <div class="container">
            <sub-container :heading="subContainer4Props.heading" />
            <div class="sub-container">
              <div class="container-2">
                <div class="text manrope-medium-white-14px">{{ text4 }}</div>
              </div>
            </div>
          </div>
          <div class="container-3">
            <div class="sub-container-3">
              <img
                class="icon"
                src="https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e0c07d5daf93032272fb1/img/icon.svg"
                alt="Icon"
              />
              <div class="heading-1 manrope-medium-mountain-mist-16px">{{ heading2 }}</div>
            </div>
            <div class="sub-container-4">
              <div class="container-4">
                <div class="heading-2">{{ heading3 }}</div>
                <div class="sub-container-5">
                  <div class="container-5">
                    <img
                      class="shape"
                      src="https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e0c07d5daf93032272fb1/img/shape.svg"
                      alt="Shape"
                    />
                    <img
                      class="shape"
                      src="https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e0c07d5daf93032272fb1/img/shape.svg"
                      alt="Shape"
                    />
                    <img
                      class="shape"
                      src="https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e0c07d5daf93032272fb1/img/shape.svg"
                      alt="Shape"
                    />
                    <img
                      class="shape"
                      src="https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e0c07d5daf93032272fb1/img/shape.svg"
                      alt="Shape"
                    />
                    <img
                      class="shape-1"
                      src="https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e0c07d5daf93032272fb1/img/shape-4.svg"
                      alt="Shape"
                    />
                  </div>
                  <div class="text manrope-medium-white-14px">{{ text5 }}</div>
                </div>
              </div>
            </div>
          </div>
          <container :text="container1Props.text" />
          <container :text="container2Props.text" />
        </div>
        <div class="button-1">
          <div class="text-1">{{ text1 }}</div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import SubContainer from "./SubContainer";
import Container from "./Container";
export default {
  name: "Screen",
  components: {
    SubContainer,
    Container,
  },
  props: [
    "heading1",
    "text",
    "text2",
    "text3",
    "text4",
    "heading2",
    "heading3",
    "text5",
    "text1",
    "subContainer1Props",
    "subContainer2Props",
    "subContainer3Props",
    "subContainer4Props",
    "container1Props",
    "container2Props",
  ],
};
</script>

<style>
.u4369u4467u4357u4457u4369u4469u4527-u4369u4454u4363u4469u4364u4469 {
  align-items: flex-start;
  background-color: var(--black10);
  display: flex;
  flex-direction: column;
  gap: 28px;
  height: 1024px;
  padding: 40px 50px;
  width: 1440px;
}

.button {
  align-items: flex-start;
  background-color: var(--gray);
  border: 1px solid;
  border-color: var(--black12);
  border-radius: 6px;
  display: flex;
  gap: 10px;
  height: 86px;
  margin-top: 10px;
  padding: 10px;
  position: relative;
  width: 86px;
}

.skip_previous_filled {
  height: 66px;
  position: relative;
  width: 66px;
}

.overlap-group {
  border-radius: 10px;
  height: 820px;
  position: relative;
  width: 416px;
}

.sub-container-1 {
  align-items: flex-start;
  background-color: var(--black06);
  border: 1px solid;
  border-color: var(--black15);
  border-radius: 10px;
  display: flex;
  flex-direction: column;
  gap: 24px;
  height: 820px;
  left: 0;
  padding: 40px;
  position: absolute;
  top: 0;
  width: 416px;
}

.container {
  align-items: flex-start;
  align-self: stretch;
  display: flex;
  flex: 0 0 auto;
  flex-direction: column;
  gap: 10px;
  position: relative;
  width: 100%;
}

.sub-container-2 {
  align-items: center;
  align-self: stretch;
  display: flex;
  flex: 0 0 auto;
  gap: 2px;
  position: relative;
  width: 100%;
}

.heading {
  color: var(--grey60);
  flex: 1;
  font-family: var(--font-family-manrope);
  font-size: var(--font-size-l);
  font-weight: 500;
  letter-spacing: 0;
  line-height: 36px;
  margin-top: -1px;
  position: relative;
}

.sub-container {
  align-items: flex-start;
  display: flex;
  flex: 0 0 auto;
  flex-wrap: wrap;
  gap: 10px 10px;
  position: relative;
  width: 82px;
}

.container-1 {
  align-items: flex-start;
  background-color: var(--black10);
  border: 1px solid;
  border-color: var(--abbey);
  border-radius: 6px;
  display: inline-flex;
  flex: 0 0 auto;
  gap: 10px;
  padding: 6px 12px;
  position: relative;
}

.text {
  letter-spacing: 0;
  line-height: 21px;
  margin-top: -1px;
  position: relative;
  white-space: nowrap;
  width: fit-content;
}

.container-2 {
  align-items: flex-start;
  background-color: var(--black10);
  border: 1px solid;
  border-color: var(--abbey);
  border-radius: 6px;
  display: inline-flex;
  flex: 0 0 auto;
  gap: 10px;
  margin-right: -94px;
  padding: 6px 12px;
  position: relative;
}

.container-3 {
  align-items: flex-start;
  display: flex;
  flex: 0 0 auto;
  flex-direction: column;
  gap: 10px;
  position: relative;
  width: 147px;
}

.sub-container-3 {
  align-items: center;
  align-self: stretch;
  display: flex;
  flex: 0 0 auto;
  gap: 4px;
  position: relative;
  width: 100%;
}

.icon {
  height: 20px;
  position: relative;
  width: 20px;
}

.heading-1 {
  flex: 1;
  letter-spacing: 0;
  line-height: 24px;
  margin-top: -1px;
  position: relative;
}

.sub-container-4 {
  align-items: flex-start;
  display: flex;
  flex: 0 0 auto;
  gap: 16px;
  position: relative;
  width: 147px;
}

.container-4 {
  align-items: flex-start;
  background-color: var(--black08);
  border: 1px solid;
  border-color: var(--abbey);
  border-radius: 8px;
  display: flex;
  flex: 1;
  flex-direction: column;
  flex-grow: 1;
  gap: 4px;
  padding: 14px;
  position: relative;
}

.heading-2 {
  color: var(--absolutewhite);
  font-family: var(--font-family-manrope);
  font-size: var(--font-size-s);
  font-weight: 600;
  letter-spacing: 0;
  line-height: 24px;
  margin-top: -1px;
  position: relative;
  white-space: nowrap;
  width: fit-content;
}

.sub-container-5 {
  align-items: center;
  display: inline-flex;
  flex: 0 0 auto;
  gap: 2px;
  position: relative;
}

.container-5 {
  align-items: flex-start;
  display: inline-flex;
  flex: 0 0 auto;
  gap: 1px;
  position: relative;
}

.shape {
  height: 16.28px;
  position: relative;
  width: 17.12px;
}

.shape-1 {
  flex: 0 0 auto;
  position: relative;
}

.button-1 {
  align-items: flex-start;
  background-color: var(--gray);
  border: 1px solid;
  border-color: var(--black12);
  border-radius: 6px;
  display: flex;
  gap: 10px;
  height: 49px;
  left: 283px;
  padding: 10px;
  position: absolute;
  top: 526px;
  transform: rotate(-180deg);
  width: 93px;
}

.text-1 {
  color: var(--absolutewhite);
  font-family: var(--font-family-manrope);
  font-size: 20px;
  font-weight: 500;
  letter-spacing: 0;
  line-height: 30px;
  margin-right: -1px;
  margin-top: -1px;
  position: relative;
  transform: rotate(180deg);
  white-space: nowrap;
  width: fit-content;
}
</style>
