<template>
  <div class="sub-container-6">
    <div class="heading-3 manrope-medium-mountain-mist-16px">{{ heading }}</div>
  </div>
</template>

<script>
export default {
  name: "SubContainer",
  props: ["heading"],
};
</script>

<style>
.sub-container-6 {
  align-items: center;
  display: flex;
  flex: 0 0 auto;
  gap: 2px;
  position: relative;
  width: 82px;
}

.heading-3 {
  flex: 1;
  letter-spacing: 0;
  line-height: 24px;
  margin-top: -1px;
  position: relative;
}
</style>
