import Vue from "vue";
import Router from "vue-router";
import XMain from "./components/XMain";
import { xMainData } from "./data";

Vue.use(Router);

export default new Router({
  mode: "history",
  routes: [
    {
      path: "*",
      component: XMain,
      props: { ...xMainData },
    },
  ],
});
