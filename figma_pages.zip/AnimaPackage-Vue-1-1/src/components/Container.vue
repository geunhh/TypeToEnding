<template>
  <div :class="[`container-1-1`, className || ``]">
    <div class="button-1">
      <div class="text-2 manrope-semi-bold-white-18px">{{ text }}</div>
    </div>
  </div>
</template>

<script>
export default {
  name: "Container",
  props: ["text", "className"],
};
</script>

<style>
.container-1-1 {
  align-items: center;
  align-self: stretch;
  display: flex;
  flex: 0 0 auto;
  gap: 70px;
  position: relative;
  width: 100%;
}

.button-1 {
  align-items: flex-start;
  background-color: var(--red45);
  border-radius: 8px;
  display: flex;
  gap: 10px;
  padding: 18px 24px;
  position: relative;
  width: 388px;
}

.text-2 {
  height: 27px;
  letter-spacing: 0;
  line-height: 27px;
  margin-top: -1px;
  position: relative;
  text-align: center;
  white-space: nowrap;
  width: 340px;
}

.container-1-1.container-1 .button-1 {
  background-color: #808080;
}

.container-1-1.container-1 .text-2 {
  height: unset;
  white-space: unset;
}
</style>
