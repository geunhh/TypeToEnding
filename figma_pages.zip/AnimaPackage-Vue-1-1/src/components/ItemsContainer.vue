<template>
  <div :class="[`items-container-1`, className || ``]">
    <div class="container">
      <div class="heading manrope-semi-bold-white-18px">{{ heading }}</div>
      <div class="input-field">
        <div class="text-1 manrope-normal-mountain-mist-18px">{{ text }}</div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "ItemsContainer",
  props: ["heading", "text", "className"],
};
</script>

<style>
.items-container-1 {
  align-items: flex-start;
  align-self: stretch;
  display: flex;
  flex: 0 0 auto;
  gap: 50px;
  position: relative;
  width: 100%;
}

.container {
  align-items: flex-start;
  display: flex;
  flex: 1;
  flex-direction: column;
  flex-grow: 1;
  gap: 16px;
  position: relative;
}

.heading {
  align-self: stretch;
  letter-spacing: 0;
  line-height: 27px;
  margin-top: -1px;
  position: relative;
}

.input-field {
  align-items: center;
  align-self: stretch;
  background-color: var(--black08);
  border: 1px solid;
  border-color: var(--black15);
  border-radius: 8px;
  display: flex;
  flex: 0 0 auto;
  gap: 77px;
  overflow: hidden;
  padding: 20px;
  position: relative;
  width: 100%;
}

.text-1 {
  flex: 1;
  letter-spacing: 0;
  line-height: 27px;
  margin-top: -1px;
  position: relative;
}

.items-container-1.items-container .input-field {
  overflow: unset;
}
</style>
