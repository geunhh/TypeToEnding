<template>
  <div class="container-center-horizontal">
    <div class="main-u4357u4457u4352u4467u4363u4469u4523-u4364u4453u4523 screen">
      <h1 class="title">{{ title }}</h1>
      <div class="overlap-group-container">
        <div class="overlap-group">
          <div class="id">{{ id }}</div>
          <div class="pw">{{ pw }}</div>
          <div class="remember-me">{{ rememberMe }}</div>
          <div class="form">
            <items-container :heading="itemsContainer1Props.heading" :text="itemsContainer1Props.text" />
            <items-container
              :heading="itemsContainer2Props.heading"
              :text="itemsContainer2Props.text"
              :className="itemsContainer2Props.className"
            />
            <container :text="container1Props.text" />
            <container :text="container2Props.text" :className="container2Props.className" />
          </div>
        </div>
        <div class="overlap-group1">
          <img class="icon-media-play" :src="iconMediaPlay" alt="icon &#34;media play&#34;" />
          <div class="button">
            <img
              class="icon"
              src="https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673df1608bbac2c0338db9f5/img/icon.svg"
              alt="Icon"
            />
            <div class="text valign-text-middle">{{ text }}</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import ItemsContainer from "./ItemsContainer";
import Container from "./Container";
export default {
  name: "XMain",
  components: {
    ItemsContainer,
    Container,
  },
  props: [
    "title",
    "id",
    "pw",
    "rememberMe",
    "iconMediaPlay",
    "text",
    "itemsContainer1Props",
    "itemsContainer2Props",
    "container1Props",
    "container2Props",
  ],
};
</script>

<style>
.main-u4357u4457u4352u4467u4363u4469u4523-u4364u4453u4523 {
  align-items: flex-start;
  background-color: var(--eerie-black);
  display: flex;
  flex-direction: column;
  gap: 10px;
  height: 1024px;
  padding: 29px 52px;
  width: 1440px;
}

.title {
  align-self: center;
  color: var(--absolutewhite);
  font-family: var(--font-family-inknut_antiqua);
  font-size: var(--font-size-xxl);
  font-weight: 400;
  letter-spacing: 0;
  line-height: normal;
  margin-top: 87px;
  min-height: 248px;
  min-width: 816px;
  text-shadow: 0px 4px 4px #00000040;
}

.overlap-group-container {
  align-items: flex-start;
  display: flex;
  gap: 543px;
  min-width: 1311px;
}

.overlap-group {
  border-radius: 12px;
  height: 621px;
  position: relative;
  width: 488px;
}

.id {
  color: var(--eerie-black);
  font-family: var(--font-family-inter);
  font-size: var(--font-size-xl);
  font-weight: 400;
  left: 38px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  top: 167px;
}

.pw {
  color: var(--eerie-black);
  font-family: var(--font-family-inter);
  font-size: var(--font-size-l);
  font-weight: 400;
  left: 38px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  top: 241px;
  width: 60px;
}

.remember-me {
  color: var(--eerie-black);
  font-family: var(--font-family-inter);
  font-size: var(--font-size-s);
  font-weight: 400;
  left: 52px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  top: 306px;
}

.form {
  align-items: flex-start;
  background-color: var(--black06);
  border: 1px solid;
  border-color: var(--black15);
  border-radius: 12px;
  display: flex;
  flex-direction: column;
  gap: 50px;
  height: 621px;
  left: 0;
  padding: 50px;
  position: absolute;
  top: 0;
  width: 488px;
}

.overlap-group1 {
  height: 82px;
  margin-top: 78px;
  position: relative;
  width: 280px;
}

.icon-media-play {
  height: 27px;
  left: 253px;
  position: absolute;
  top: 0;
  width: 27px;
}

.button {
  align-items: center;
  background-color: var(--red45);
  border-radius: 8px;
  display: flex;
  gap: 4px;
  height: 63px;
  left: 0;
  padding: 18px 24px;
  position: absolute;
  top: 19px;
  width: 280px;
}

.icon {
  height: 28px;
  margin-bottom: -0.5px;
  margin-top: -0.5px;
  position: relative;
  width: 28px;
}

.text {
  color: var(--absolutewhite);
  font-family: var(--font-family-manrope);
  font-size: var(--font-size-l);
  font-weight: 600;
  height: 63px;
  letter-spacing: 0;
  line-height: 48px;
  margin-bottom: -17px;
  margin-right: -3px;
  margin-top: -19px;
  position: relative;
  text-align: center;
  width: 203px;
}
</style>
