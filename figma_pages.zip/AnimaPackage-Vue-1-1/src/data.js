export const itemsContainer1Data = {
    heading: "ID",
    text: "Enter your ID",
};

export const itemsContainer2Data = {
    heading: "Password",
    text: "Enter your password",
    className: "items-container",
};

export const container1Data = {
    text: "Sign in",
};

export const container2Data = {
    text: "Sign Up",
    className: "container-1",
};

export const xMainData = {
    title: "Type to Ending",
    id: "ID",
    pw: "PW",
    rememberMe: "remember me",
    iconMediaPlay: "https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673df1608bbac2c0338db9f5/img/---icon--media-play-@2x.png",
    text: "How to play",
    itemsContainer1Props: itemsContainer1Data,
    itemsContainer2Props: itemsContainer2Data,
    container1Props: container1Data,
    container2Props: container2Data,
};

