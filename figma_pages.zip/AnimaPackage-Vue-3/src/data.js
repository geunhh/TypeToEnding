export const container21Data = {
    text: "Profile",
};

export const container22Data = {
    text: "Create Room",
};

export const container23Data = {
    text: "Enter Room",
};

export const container24Data = {
    text: "Sign Out",
    className: "container",
};

export const xForm1Data = {
    container21Props: container21Data,
    container22Props: container22Data,
    container23Props: container23Data,
    container24Props: container24Data,
};

export const textContainer1Data = {
    heading: "영화 추천",
    paragraph: "당신이 작성한 시나리오에 맞춰 영화를 추천합니다.",
};

export const popUpHowToPlay6Data = {
    xFormProps: xForm1Data,
    textContainerProps: textContainer1Data,
};

export const container25Data = {
    text: "Profile",
};

export const container26Data = {
    text: "Create Room",
};

export const container27Data = {
    text: "Enter Room",
};

export const container28Data = {
    text: "Sign Out",
    className: "container-1",
};

export const xForm2Data = {
    container21Props: container25Data,
    container22Props: container26Data,
    container23Props: container27Data,
    container24Props: container28Data,
};

export const textContainer2Data = {
    heading: "결말 확인",
    paragraph: "시나리오 작성 과정을 5회 거친 후 결말을 확인합니다.",
};

export const popUpHowToPlay5Data = {
    xFormProps: xForm2Data,
    textContainerProps: textContainer2Data,
};

export const container29Data = {
    text: "Profile",
};

export const container210Data = {
    text: "Create Room",
};

export const container211Data = {
    text: "Enter Room",
};

export const container212Data = {
    text: "Sign Out",
    className: "container-2",
};

export const xForm3Data = {
    container21Props: container29Data,
    container22Props: container210Data,
    container23Props: container211Data,
    container24Props: container212Data,
};

export const textContainer3Data = {
    heading: "결과 확인",
    paragraph: "평가 결과에 따라 당신의 시나리오가 ‘폐기’ 또는 ‘채택’ 됩니다.",
};

export const popUpHowToPlay4Data = {
    xFormProps: xForm3Data,
    textContainerProps: textContainer3Data,
};

export const container213Data = {
    text: "Profile",
};

export const container214Data = {
    text: "Create Room",
};

export const container215Data = {
    text: "Enter Room",
};

export const container216Data = {
    text: "Sign Out",
    className: "container-3",
};

export const xForm4Data = {
    container21Props: container213Data,
    container22Props: container214Data,
    container23Props: container215Data,
    container24Props: container216Data,
};

export const textContainer4Data = {
    heading: "AI 평가 진행",
    paragraph: "작성한 시나리오의 창의, 논리, 개연성을 토대로 당신의 시나리오를 평가합니다.",
};

export const imageContainer1Data = {
    image1: "https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e0e9940ace40448c5fca3/img/image-5@2x.png",
    image2: "https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e0e9940ace40448c5fca3/img/image-6@2x.png",
    image3: "https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e0e9940ace40448c5fca3/img/image-7@2x.png",
    image4: "https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e0e9940ace40448c5fca3/img/image-8@2x.png",
};

export const imageContainer2Data = {
    image1: "https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e0e9940ace40448c5fca3/img/image-9@2x.png",
    image2: "https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e0e9940ace40448c5fca3/img/image-10@2x.png",
    image3: "https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e0e9940ace40448c5fca3/img/image-11@2x.png",
    image4: "https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e0e9940ace40448c5fca3/img/image-12@2x.png",
};

export const imageContainer3Data = {
    image1: "https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e0e9940ace40448c5fca3/img/image-13@2x.png",
    image2: "https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e0e9940ace40448c5fca3/img/image-14@2x.png",
    image3: "https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e0e9940ace40448c5fca3/img/image-15@2x.png",
    image4: "https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e0e9940ace40448c5fca3/img/image-16@2x.png",
};

export const container1Data = {
    imageContainer1Props: imageContainer1Data,
    imageContainer2Props: imageContainer2Data,
    imageContainer3Props: imageContainer3Data,
};

export const popUpHowToPlay3Data = {
    xFormProps: xForm4Data,
    textContainerProps: textContainer4Data,
    containerProps: container1Data,
};

export const container217Data = {
    text: "Profile",
};

export const container218Data = {
    text: "Create Room",
};

export const container219Data = {
    text: "Enter Room",
};

export const container220Data = {
    text: "Sign Out",
    className: "container-4",
};

export const xForm5Data = {
    container21Props: container217Data,
    container22Props: container218Data,
    container23Props: container219Data,
    container24Props: container220Data,
};

export const textContainer5Data = {
    heading: "시나리오 작성",
    paragraph: "AI가 제공한 시나리오에 이어질 시나리오를 작성합니다.",
};

export const imageContainer4Data = {
    image1: "https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e0e9940ace40448c5fca3/img/image-5@2x.png",
    image2: "https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e0e9940ace40448c5fca3/img/image-6@2x.png",
    image3: "https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e0e9940ace40448c5fca3/img/image-7@2x.png",
    image4: "https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e0e9940ace40448c5fca3/img/image-8@2x.png",
};

export const imageContainer5Data = {
    image1: "https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e0e9940ace40448c5fca3/img/image-9@2x.png",
    image2: "https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e0e9940ace40448c5fca3/img/image-10@2x.png",
    image3: "https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e0e9940ace40448c5fca3/img/image-11@2x.png",
    image4: "https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e0e9940ace40448c5fca3/img/image-12@2x.png",
};

export const imageContainer6Data = {
    image1: "https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e0e9940ace40448c5fca3/img/image-13@2x.png",
    image2: "https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e0e9940ace40448c5fca3/img/image-14@2x.png",
    image3: "https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e0e9940ace40448c5fca3/img/image-15@2x.png",
    image4: "https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e0e9940ace40448c5fca3/img/image-16@2x.png",
};

export const container3Data = {
    className: "container-10",
    imageContainer1Props: imageContainer4Data,
    imageContainer2Props: imageContainer5Data,
    imageContainer3Props: imageContainer6Data,
};

export const popUpHowToPlay2Data = {
    xFormProps: xForm5Data,
    textContainerProps: textContainer5Data,
    containerProps: container3Data,
};

export const container221Data = {
    text: "Profile",
};

export const container222Data = {
    text: "Create Room",
};

export const container223Data = {
    text: "Enter Room",
};

export const container224Data = {
    text: "Sign Out",
    className: "container-5",
};

export const xForm6Data = {
    container21Props: container221Data,
    container22Props: container222Data,
    container23Props: container223Data,
    container24Props: container224Data,
};

export const textContainer6Data = {
    heading: "영화 선택",
    paragraph: "내가 제작할 영화의 배경과 기본 시나리오를 제공할 영화를 선택합니다.",
};

export const imageContainer7Data = {
    image1: "https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e0e9940ace40448c5fca3/img/image-5@2x.png",
    image2: "https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e0e9940ace40448c5fca3/img/image-6@2x.png",
    image3: "https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e0e9940ace40448c5fca3/img/image-7@2x.png",
    image4: "https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e0e9940ace40448c5fca3/img/image-8@2x.png",
};

export const imageContainer8Data = {
    image1: "https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e0e9940ace40448c5fca3/img/image-9@2x.png",
    image2: "https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e0e9940ace40448c5fca3/img/image-10@2x.png",
    image3: "https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e0e9940ace40448c5fca3/img/image-11@2x.png",
    image4: "https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e0e9940ace40448c5fca3/img/image-12@2x.png",
};

export const imageContainer9Data = {
    image1: "https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e0e9940ace40448c5fca3/img/image-13@2x.png",
    image2: "https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e0e9940ace40448c5fca3/img/image-14@2x.png",
    image3: "https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e0e9940ace40448c5fca3/img/image-15@2x.png",
    image4: "https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e0e9940ace40448c5fca3/img/image-16@2x.png",
};

export const container4Data = {
    className: "container-11",
    imageContainer1Props: imageContainer7Data,
    imageContainer2Props: imageContainer8Data,
    imageContainer3Props: imageContainer9Data,
};

export const frameData = {
    xFormProps: xForm6Data,
    textContainerProps: textContainer6Data,
    containerProps: container4Data,
};

