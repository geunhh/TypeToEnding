<template>
  <div class="container-center-horizontal">
    <div class="popup-how-to-play-4 screen">
      <div class="overlap-group-2">
        <h1 class="title-2 inknutantiqua-normal-white-96px">{{ title }}</h1>
        <x-form
          :container21Props="xFormProps.container21Props"
          :container22Props="xFormProps.container22Props"
          :container23Props="xFormProps.container23Props"
          :container24Props="xFormProps.container24Props"
        />
        <x-button />
        <div class="rectangle-514-2"></div>
        <div class="sub-container-4">
          <text-container :heading="textContainerProps.heading" :paragraph="textContainerProps.paragraph" />
          <div class="sub-container-5">
            <img class="image-5" :src="image5" alt="image 5" /><img class="image-6" :src="image6" alt="image 6" />
          </div>
        </div>
        <buttons-container />
      </div>
      <img class="icon-task-2" :src="iconTask" alt="icon &#34;task&#34;" />
    </div>
  </div>
</template>

<script>
import XForm from "./XForm";
import XButton from "./XButton";
import TextContainer from "./TextContainer";
import ButtonsContainer from "./ButtonsContainer";
export default {
  name: "PopUpHowToPlay4",
  components: {
    XForm,
    XButton,
    TextContainer,
    ButtonsContainer,
  },
  props: ["title", "image5", "image6", "iconTask", "xFormProps", "textContainerProps"],
};
</script>

<style>
.popup-how-to-play-4 {
  align-items: flex-start;
  background-color: var(--eerie-black);
  display: flex;
  gap: 160px;
  height: 1024px;
  overflow: hidden;
  width: 1440px;
}

.overlap-group-2 {
  height: 907px;
  margin-left: 46px;
  margin-top: 79px;
  position: relative;
  width: 1317px;
}

.title-2 {
  left: 266px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  text-shadow: 0px 4px 4px #00000040;
  top: 37px;
}

.rectangle-514-2 {
  background-color: var(--black06);
  border: 2px solid;
  border-color: var(--dusty-gray);
  border-radius: 20px;
  height: 865px;
  left: 169px;
  position: absolute;
  top: 0;
  width: 1009px;
}

.sub-container-4 {
  align-items: flex-start;
  display: flex;
  flex-direction: column;
  gap: 50px;
  height: 739px;
  left: 299px;
  position: absolute;
  top: 87px;
  width: 731px;
}

.sub-container-5 {
  align-self: stretch;
  background-color: var(--black06);
  border: 6px solid;
  border-color: var(--black15);
  border-radius: 6px;
  height: 459px;
  margin-left: -6px;
  margin-right: -6px;
  overflow: hidden;
  position: relative;
  width: 100%;
}

.image-5 {
  height: 447px;
  left: 29px;
  object-fit: cover;
  position: absolute;
  top: 0;
  width: 299px;
}

.image-6 {
  height: 447px;
  left: 395px;
  object-fit: cover;
  position: absolute;
  top: 0;
  width: 315px;
}

.icon-task-2 {
  height: 20px;
  margin-top: 2867px;
  width: 23px;
}
</style>
