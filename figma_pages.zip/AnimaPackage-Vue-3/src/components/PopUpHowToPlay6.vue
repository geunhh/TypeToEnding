<template>
  <div class="container-center-horizontal">
    <div class="popup-how-to-play-6 screen">
      <img class="icon-task" :src="iconTask" alt="icon &#34;task&#34;" />
      <div class="overlap-group">
        <h1 class="title inknutantiqua-normal-white-96px">{{ title }}</h1>
        <x-form
          :container21Props="xFormProps.container21Props"
          :container22Props="xFormProps.container22Props"
          :container23Props="xFormProps.container23Props"
          :container24Props="xFormProps.container24Props"
        />
        <x-button />
        <div class="rectangle-514"></div>
        <div class="sub-container">
          <text-container :heading="textContainerProps.heading" :paragraph="textContainerProps.paragraph" />
          <div class="sub-container-1"><img class="image-8" :src="image8" alt="image 8" /></div>
        </div>
        <buttons-container />
      </div>
    </div>
  </div>
</template>

<script>
import XForm from "./XForm";
import XButton from "./XButton";
import TextContainer from "./TextContainer";
import ButtonsContainer from "./ButtonsContainer";
export default {
  name: "PopUpHowToPlay6",
  components: {
    XForm,
    XButton,
    TextContainer,
    ButtonsContainer,
  },
  props: ["iconTask", "title", "image8", "xFormProps", "textContainerProps"],
};
</script>

<style>
.popup-how-to-play-6 {
  align-items: flex-start;
  background-color: var(--eerie-black);
  display: flex;
  gap: 1460px;
  height: 1024px;
  overflow: hidden;
  width: 1440px;
}

.icon-task {
  height: 20px;
  margin-left: -1437px;
  margin-top: 2867px;
  width: 23px;
}

.overlap-group {
  height: 907px;
  margin-top: 79px;
  position: relative;
  width: 1317px;
}

.title {
  left: 266px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  text-shadow: 0px 4px 4px #00000040;
  top: 37px;
}

.rectangle-514 {
  background-color: var(--black06);
  border: 2px solid;
  border-color: var(--dusty-gray);
  border-radius: 20px;
  height: 865px;
  left: 169px;
  position: absolute;
  top: 0;
  width: 1009px;
}

.sub-container {
  align-items: flex-start;
  display: flex;
  flex-direction: column;
  gap: 50px;
  height: 739px;
  left: 299px;
  position: absolute;
  top: 87px;
  width: 731px;
}

.sub-container-1 {
  align-self: stretch;
  background-color: var(--black06);
  border: 6px solid;
  border-color: var(--black15);
  border-radius: 6px;
  height: 459px;
  margin-left: -6px;
  margin-right: -6px;
  overflow: hidden;
  position: relative;
  width: 100%;
}

.image-8 {
  height: 447px;
  left: 107px;
  object-fit: cover;
  position: absolute;
  top: 0;
  width: 513px;
}
</style>
