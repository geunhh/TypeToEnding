<template>
  <div class="text-container">
    <div class="heading valign-text-middle manrope-extra-bold-white-48px">{{ heading }}</div>
    <p class="paragraph valign-text-middle manrope-normal-mountain-mist-18px">{{ paragraph }}</p>
  </div>
</template>

<script>
export default {
  name: "TextContainer",
  props: ["heading", "paragraph"],
};
</script>

<style>
.text-container,
.text-container-1,
.text-container-2,
.text-container-3,
.text-container-4,
.text-container-5 {
  align-items: flex-start;
  align-self: stretch;
  display: flex;
  flex: 0 0 auto;
  flex-direction: column;
  gap: 14px;
  position: relative;
  width: 100%;
}

.heading,
.heading-1,
.heading-2,
.heading-3,
.heading-4,
.heading-5 {
  align-self: stretch;
  letter-spacing: 0;
  line-height: 72px;
  margin-top: -1px;
  position: relative;
  text-align: center;
}

.paragraph,
.paragraph-1,
.paragraph-2,
.paragraph-3,
.paragraph-4,
.paragraph-5 {
  align-self: stretch;
  letter-spacing: 0;
  line-height: 27px;
  position: relative;
  text-align: center;
}
</style>
