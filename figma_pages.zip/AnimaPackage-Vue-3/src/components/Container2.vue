<template>
  <div :class="[`container-6`, className || ``]">
    <div class="button-6">
      <div class="text manrope-semi-bold-white-18px">{{ text }}</div>
    </div>
  </div>
</template>

<script>
export default {
  name: "Container2",
  props: ["text", "className"],
};
</script>

<style>
.container-6 {
  align-items: center;
  align-self: stretch;
  display: flex;
  flex: 0 0 auto;
  gap: 70px;
  position: relative;
  width: 100%;
}

.button-6 {
  align-items: flex-start;
  background-color: var(--red45);
  border-radius: 8px;
  display: flex;
  gap: 10px;
  padding: 18px 24px;
  position: relative;
  width: 388px;
}

.text {
  height: 27px;
  letter-spacing: 0;
  line-height: 27px;
  margin-top: -1px;
  position: relative;
  text-align: center;
  white-space: nowrap;
  width: 340px;
}

.container-6.container .button-6,
.container-6.container-1 .button-6,
.container-6.container-2 .button-6,
.container-6.container-3 .button-6,
.container-6.container-4 .button-6,
.container-6.container-5 .button-6 {
  background-color: var(--gray);
}

.container-6.container .text,
.container-6.container-1 .text,
.container-6.container-2 .text,
.container-6.container-3 .text,
.container-6.container-4 .text,
.container-6.container-5 .text {
  height: unset;
  white-space: unset;
}
</style>
