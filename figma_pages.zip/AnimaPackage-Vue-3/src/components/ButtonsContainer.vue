<template>
  <div class="buttons-container">
    <img
      class="button-18"
      src="https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e0e9940ace40448c5fca3/img/button.svg"
      alt="Button"
    />
    <div class="indicators-container">
      <div class="shape"></div>
      <div class="shape"></div>
      <div class="shape"></div>
      <div class="shape"></div>
      <div class="shape"></div>
      <div class="shape-3"></div>
    </div>
    <img
      class="button-18"
      src="https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e0e9940ace40448c5fca3/img/button-1.svg"
      alt="Button"
    />
  </div>
</template>

<script>
export default {
  name: "ButtonsContainer",
};
</script>

<style>
.buttons-container,
.buttons-container-1,
.buttons-container-2 {
  align-items: center;
  display: inline-flex;
  gap: 10px;
  left: 570px;
  position: absolute;
  top: 769px;
}

.button-18,
.button-19,
.button-20 {
  flex: 0 0 auto;
  position: relative;
}

.indicators-container,
.indicators-container-1,
.indicators-container-2 {
  align-items: flex-start;
  display: flex;
  gap: 3px;
  position: relative;
  width: 81px;
}

.shape,
.shape-1,
.shape-2 {
  background-color: var(--black20);
  border-radius: 100px;
  flex: 1;
  flex-grow: 1;
  height: 4px;
  position: relative;
}

.shape-3,
.shape-4,
.shape-5 {
  background-color: var(--red45);
  border-radius: 100px;
  height: 4px;
  position: relative;
  width: 23px;
}
</style>
