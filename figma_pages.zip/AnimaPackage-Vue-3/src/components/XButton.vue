<template>
  <div class="button-12">
    <img
      class="icon"
      src="https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e07b140ace40448c5fc73/img/icon.svg"
      alt="Icon"
    />
    <div class="text-1 valign-text-middle manrope-semi-bold-white-32px">How to play</div>
  </div>
</template>

<script>
export default {
  name: "XButton",
};
</script>

<style>
.button-12,
.button-13,
.button-14,
.button-15,
.button-16,
.button-17 {
  align-items: center;
  background-color: var(--red45);
  border-radius: 8px;
  display: flex;
  gap: 4px;
  height: 63px;
  left: 1037px;
  padding: 18px 24px;
  position: absolute;
  top: 354px;
  width: 280px;
}

.icon,
.icon-1,
.icon-2,
.icon-3,
.icon-4,
.icon-5 {
  height: 28px;
  margin-bottom: -0.5px;
  margin-top: -0.5px;
  position: relative;
  width: 28px;
}

.text-1,
.text-3,
.text-5,
.text-7,
.text-9,
.text-11 {
  height: 63px;
  letter-spacing: 0;
  line-height: 48px;
  margin-bottom: -17px;
  margin-right: -3px;
  margin-top: -19px;
  position: relative;
  text-align: center;
  width: 203px;
}
</style>
