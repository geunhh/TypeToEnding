<template>
  <div class="image-container-3">
    <img class="image-3" :src="image1" alt="Image" /><img class="image-3" :src="image2" alt="Image" /><img
      class="image-3"
      :src="image3"
      alt="Image"
    /><img class="image-3" :src="image4" alt="Image" />
  </div>
</template>

<script>
export default {
  name: "ImageContainer",
  props: ["image1", "image2", "image3", "image4"],
};
</script>

<style>
.image-container-3,
.image-container-4,
.image-container-5 {
  align-items: flex-start;
  align-self: stretch;
  display: flex;
  flex: 1;
  flex-grow: 1;
  gap: 20px;
  position: relative;
  width: 100%;
}

.image-3,
.image-9,
.image-10 {
  align-self: stretch;
  flex: 1;
  flex-grow: 1;
  object-fit: cover;
  position: relative;
}
</style>
