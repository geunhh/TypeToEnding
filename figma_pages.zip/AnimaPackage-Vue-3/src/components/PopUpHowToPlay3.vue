<template>
  <div class="container-center-horizontal">
    <div class="popup-how-to-play-3 screen">
      <div class="overlap-group-3">
        <h1 class="title-3 inknutantiqua-normal-white-96px">{{ title }}</h1>
        <x-form
          :container21Props="xFormProps.container21Props"
          :container22Props="xFormProps.container22Props"
          :container23Props="xFormProps.container23Props"
          :container24Props="xFormProps.container24Props"
        />
        <x-button />
        <div class="rectangle-514-3"></div>
        <div class="sub-container-6">
          <text-container :heading="textContainerProps.heading" :paragraph="textContainerProps.paragraph" />
          <div class="sub-container-7">
            <container
              :imageContainer1Props="containerProps.imageContainer1Props"
              :imageContainer2Props="containerProps.imageContainer2Props"
              :imageContainer3Props="containerProps.imageContainer3Props"
            />
          </div>
        </div>
        <div class="buttons-container-3">
          <img
            class="button-21"
            src="https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e0e9940ace40448c5fca3/img/button.svg"
            alt="Button"
          />
          <div class="indicators-container-3">
            <div class="shape-6"></div>
            <div class="shape-6"></div>
            <div class="shape-6"></div>
            <div class="shape-6"></div>
            <div class="shape-7"></div>
            <div class="shape-6"></div>
          </div>
          <img
            class="button-21"
            src="https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e0e9940ace40448c5fca3/img/button-1.svg"
            alt="Button"
          />
        </div>
        <img class="image-4" :src="image4" alt="image 4" />
      </div>
      <img class="icon-task-3" :src="iconTask" alt="icon &#34;task&#34;" />
    </div>
  </div>
</template>

<script>
import XForm from "./XForm";
import XButton from "./XButton";
import TextContainer from "./TextContainer";
import Container from "./Container";
export default {
  name: "PopUpHowToPlay3",
  components: {
    XForm,
    XButton,
    TextContainer,
    Container,
  },
  props: ["title", "image4", "iconTask", "xFormProps", "textContainerProps", "containerProps"],
};
</script>

<style>
.popup-how-to-play-3 {
  align-items: flex-start;
  background-color: var(--eerie-black);
  display: flex;
  gap: 1640px;
  height: 1024px;
  overflow: hidden;
  width: 1440px;
}

.overlap-group-3 {
  height: 907px;
  margin-left: 46px;
  margin-top: 79px;
  position: relative;
  width: 1317px;
}

.title-3 {
  left: 266px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  text-shadow: 0px 4px 4px #00000040;
  top: 37px;
}

.rectangle-514-3 {
  background-color: var(--black06);
  border: 2px solid;
  border-color: var(--dusty-gray);
  border-radius: 20px;
  height: 865px;
  left: 169px;
  position: absolute;
  top: 0;
  width: 1009px;
}

.sub-container-6 {
  align-items: flex-start;
  display: flex;
  flex-direction: column;
  gap: 50px;
  height: 739px;
  left: 299px;
  position: absolute;
  top: 87px;
  width: 731px;
}

.sub-container-7 {
  align-self: stretch;
  background-color: var(--black06);
  border: 6px solid;
  border-color: var(--black15);
  border-radius: 6px;
  height: 459px;
  margin-left: -6px;
  margin-right: -6px;
  overflow: hidden;
  position: relative;
  width: 100%;
}

.buttons-container-3 {
  align-items: center;
  display: inline-flex;
  gap: 10px;
  left: 570px;
  position: absolute;
  top: 769px;
}

.button-21 {
  flex: 0 0 auto;
  position: relative;
}

.indicators-container-3 {
  align-items: flex-start;
  display: flex;
  gap: 3px;
  position: relative;
  width: 81px;
}

.shape-6 {
  background-color: var(--black20);
  border-radius: 100px;
  flex: 1;
  flex-grow: 1;
  height: 4px;
  position: relative;
}

.shape-7 {
  background-color: var(--red45);
  border-radius: 100px;
  height: 4px;
  position: relative;
  width: 23px;
}

.image-4 {
  height: 450px;
  left: 300px;
  object-fit: cover;
  position: absolute;
  top: 247px;
  width: 730px;
}

.icon-task-3 {
  height: 20px;
  margin-top: 2867px;
  width: 23px;
}
</style>
