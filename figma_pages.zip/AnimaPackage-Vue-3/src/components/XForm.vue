<template>
  <div class="form">
    <container2 :text="container21Props.text" />
    <container2 :text="container22Props.text" />
    <container2 :text="container23Props.text" />
    <div class="dummy">
      <div class="button"></div>
    </div>
    <container2 :text="container24Props.text" :className="container24Props.className" />
  </div>
</template>

<script>
import Container2 from "./Container2";
export default {
  name: "XForm",
  components: {
    Container2,
  },
  props: ["container21Props", "container22Props", "container23Props", "container24Props"],
};
</script>

<style>
.form,
.form-1,
.form-2,
.form-3,
.form-4,
.form-5 {
  align-items: flex-start;
  background-color: var(--black06);
  border: 1px solid;
  border-color: var(--black15);
  border-radius: 12px;
  display: inline-flex;
  flex-direction: column;
  gap: 50px;
  height: 621px;
  left: 0;
  padding: 50px;
  position: absolute;
  top: 286px;
}

.dummy,
.dummy-1,
.dummy-2,
.dummy-3,
.dummy-4,
.dummy-5 {
  align-items: center;
  align-self: stretch;
  display: flex;
  flex: 0 0 auto;
  gap: 70px;
  position: relative;
  width: 100%;
}

.button,
.button-1,
.button-2,
.button-3,
.button-4,
.button-5 {
  border-radius: 8px;
  position: relative;
  width: 388px;
}
</style>
