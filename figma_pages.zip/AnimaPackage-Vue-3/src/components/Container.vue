<template>
  <div :class="[`container-9`, className || ``]">
    <div class="image-container">
      <img
        class="image"
        src="https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e0e9940ace40448c5fca3/img/image@2x.png"
        alt="Image"
      />
      <img
        class="image"
        src="https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e0e9940ace40448c5fca3/img/image-1@2x.png"
        alt="Image"
      />
      <img
        class="image"
        src="https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e0e9940ace40448c5fca3/img/image-3@2x.png"
        alt="Image"
      />
      <img
        class="image"
        src="https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e0e9940ace40448c5fca3/img/image-4@2x.png"
        alt="Image"
      />
    </div>
    <image-container
      :image1="imageContainer1Props.image1"
      :image2="imageContainer1Props.image2"
      :image3="imageContainer1Props.image3"
      :image4="imageContainer1Props.image4"
    />
    <image-container
      :image1="imageContainer2Props.image1"
      :image2="imageContainer2Props.image2"
      :image3="imageContainer2Props.image3"
      :image4="imageContainer2Props.image4"
    />
    <image-container
      :image1="imageContainer3Props.image1"
      :image2="imageContainer3Props.image2"
      :image3="imageContainer3Props.image3"
      :image4="imageContainer3Props.image4"
    />
  </div>
</template>

<script>
import ImageContainer from "./ImageContainer";
export default {
  name: "Container",
  components: {
    ImageContainer,
  },
  props: ["className", "imageContainer1Props", "imageContainer2Props", "imageContainer3Props"],
};
</script>

<style>
.container-9 {
  align-items: flex-start;
  display: flex;
  flex-direction: column;
  gap: 20px;
  height: 733px;
  left: 62px;
  position: relative;
  top: -153px;
  width: 601px;
}

.image-container {
  align-items: flex-start;
  align-self: stretch;
  display: flex;
  flex: 1;
  flex-grow: 1;
  gap: 20px;
  position: relative;
  width: 100%;
}

.image {
  align-self: stretch;
  flex: 1;
  flex-grow: 1;
  object-fit: cover;
  position: relative;
}

.container-9.container-10,
.container-9.container-11 {
  position: absolute;
  top: 0;
}
</style>
