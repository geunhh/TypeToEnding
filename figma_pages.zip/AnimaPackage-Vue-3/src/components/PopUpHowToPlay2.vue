<template>
  <div class="container-center-horizontal">
    <div class="popup-how-to-play-2 screen">
      <div class="overlap-group1">
        <h1 class="title-4 inknutantiqua-normal-white-96px">{{ title }}</h1>
        <x-form
          :container21Props="xFormProps.container21Props"
          :container22Props="xFormProps.container22Props"
          :container23Props="xFormProps.container23Props"
          :container24Props="xFormProps.container24Props"
        />
        <x-button />
        <div class="rectangle-514-4"></div>
        <div class="sub-container-8">
          <text-container :heading="textContainerProps.heading" :paragraph="textContainerProps.paragraph" />
          <div class="sub-container-9">
            <div class="overlap-group-4">
              <container
                :className="containerProps.className"
                :imageContainer1Props="containerProps.imageContainer1Props"
                :imageContainer2Props="containerProps.imageContainer2Props"
                :imageContainer3Props="containerProps.imageContainer3Props"
              />
              <img class="image-3-1" :src="image3" alt="image 3" />
            </div>
          </div>
        </div>
        <div class="buttons-container-4">
          <img
            class="button-22"
            src="https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e0e9940ace40448c5fca3/img/button.svg"
            alt="Button"
          />
          <div class="indicators-container-4">
            <div class="shape-8"></div>
            <div class="shape-9"></div>
            <div class="shape-8"></div>
            <div class="shape-8"></div>
            <div class="shape-8"></div>
            <div class="shape-8"></div>
          </div>
          <img
            class="button-22"
            src="https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e0e9940ace40448c5fca3/img/button-1.svg"
            alt="Button"
          />
        </div>
      </div>
      <img class="icon-task-4" :src="iconTask" alt="icon &#34;task&#34;" />
    </div>
  </div>
</template>

<script>
import XForm from "./XForm";
import XButton from "./XButton";
import TextContainer from "./TextContainer";
import Container from "./Container";
export default {
  name: "PopUpHowToPlay2",
  components: {
    XForm,
    XButton,
    TextContainer,
    Container,
  },
  props: ["title", "image3", "iconTask", "xFormProps", "textContainerProps", "containerProps"],
};
</script>

<style>
.popup-how-to-play-2 {
  align-items: flex-start;
  background-color: var(--eerie-black);
  display: flex;
  gap: 3120px;
  height: 1024px;
  overflow: hidden;
  width: 1440px;
}

.overlap-group1 {
  height: 907px;
  margin-left: 46px;
  margin-top: 79px;
  position: relative;
  width: 1317px;
}

.title-4 {
  left: 266px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  text-shadow: 0px 4px 4px #00000040;
  top: 37px;
}

.rectangle-514-4 {
  background-color: var(--black06);
  border: 2px solid;
  border-color: var(--dusty-gray);
  border-radius: 20px;
  height: 865px;
  left: 169px;
  position: absolute;
  top: 0;
  width: 1009px;
}

.sub-container-8 {
  align-items: flex-start;
  display: flex;
  flex-direction: column;
  gap: 50px;
  height: 739px;
  left: 299px;
  position: absolute;
  top: 87px;
  width: 731px;
}

.sub-container-9 {
  align-self: stretch;
  background-color: var(--black06);
  border: 6px solid;
  border-color: var(--black15);
  border-radius: 6px;
  height: 459px;
  margin-left: -6px;
  margin-right: -6px;
  overflow: hidden;
  position: relative;
  width: 100%;
}

.overlap-group-4 {
  height: 733px;
  position: relative;
  top: -153px;
  width: 731px;
}

.image-3-1 {
  height: 447px;
  left: 0;
  object-fit: cover;
  position: absolute;
  top: 153px;
  width: 731px;
}

.buttons-container-4 {
  align-items: center;
  display: inline-flex;
  gap: 10px;
  left: 570px;
  position: absolute;
  top: 769px;
}

.button-22 {
  flex: 0 0 auto;
  position: relative;
}

.indicators-container-4 {
  align-items: flex-start;
  display: flex;
  gap: 3px;
  position: relative;
  width: 81px;
}

.shape-8 {
  background-color: var(--black20);
  border-radius: 100px;
  flex: 1;
  flex-grow: 1;
  height: 4px;
  position: relative;
}

.shape-9 {
  background-color: var(--red45);
  border-radius: 100px;
  height: 4px;
  position: relative;
  width: 23px;
}

.icon-task-4 {
  height: 20px;
  margin-top: 2867px;
  width: 23px;
}
</style>
