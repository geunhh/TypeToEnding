<template>
  <div class="container-center-horizontal">
    <div class="frame screen">
      <div class="overlap-group1-1">
        <h1 class="title-5 inknutantiqua-normal-white-96px">{{ title }}</h1>
        <x-form
          :container21Props="xFormProps.container21Props"
          :container22Props="xFormProps.container22Props"
          :container23Props="xFormProps.container23Props"
          :container24Props="xFormProps.container24Props"
        />
        <x-button />
        <div class="rectangle-514-5"></div>
        <div class="sub-container-10">
          <text-container :heading="textContainerProps.heading" :paragraph="textContainerProps.paragraph" />
          <div class="sub-container-11">
            <div class="overlap-group-5">
              <container
                :className="containerProps.className"
                :imageContainer1Props="containerProps.imageContainer1Props"
                :imageContainer2Props="containerProps.imageContainer2Props"
                :imageContainer3Props="containerProps.imageContainer3Props"
              />
              <img class="image-2-1" :src="image2" alt="image 2" />
            </div>
          </div>
        </div>
        <div class="buttons-container-5">
          <img
            class="button-23"
            src="https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e0e9940ace40448c5fca3/img/button.svg"
            alt="Button"
          />
          <div class="indicators-container-5">
            <div class="shape-11"></div>
            <div class="shape-10"></div>
            <div class="shape-10"></div>
            <div class="shape-10"></div>
            <div class="shape-10"></div>
            <div class="shape-10"></div>
          </div>
          <img
            class="button-23"
            src="https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e0e9940ace40448c5fca3/img/button-1.svg"
            alt="Button"
          />
        </div>
      </div>
      <img class="icon-task-5" :src="iconTask" alt="icon &#34;task&#34;" />
    </div>
  </div>
</template>

<script>
import XForm from "./XForm";
import XButton from "./XButton";
import TextContainer from "./TextContainer";
import Container from "./Container";
export default {
  name: "Frame",
  components: {
    XForm,
    XButton,
    TextContainer,
    Container,
  },
  props: ["title", "image2", "iconTask", "xFormProps", "textContainerProps", "containerProps"],
};
</script>

<style>
.frame {
  align-items: flex-start;
  background-color: var(--eerie-black);
  display: flex;
  gap: 4600px;
  height: 1024px;
  overflow: hidden;
  width: 1440px;
}

.overlap-group1-1 {
  height: 907px;
  margin-left: 46px;
  margin-top: 79px;
  position: relative;
  width: 1317px;
}

.title-5 {
  left: 266px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  text-shadow: 0px 4px 4px #00000040;
  top: 37px;
}

.rectangle-514-5 {
  background-color: var(--black06);
  border: 2px solid;
  border-color: var(--dusty-gray);
  border-radius: 20px;
  height: 865px;
  left: 169px;
  position: absolute;
  top: 0;
  width: 1009px;
}

.sub-container-10 {
  align-items: flex-start;
  display: flex;
  flex-direction: column;
  gap: 50px;
  height: 739px;
  left: 299px;
  position: absolute;
  top: 87px;
  width: 731px;
}

.sub-container-11 {
  align-self: stretch;
  background-color: var(--black06);
  border: 6px solid;
  border-color: var(--black15);
  border-radius: 6px;
  height: 459px;
  margin-left: -6px;
  margin-right: -6px;
  overflow: hidden;
  position: relative;
  width: 100%;
}

.overlap-group-5 {
  height: 733px;
  position: relative;
  top: -153px;
  width: 742px;
}

.image-2-1 {
  height: 446px;
  left: 0;
  object-fit: cover;
  position: absolute;
  top: 154px;
  width: 742px;
}

.buttons-container-5 {
  align-items: center;
  display: inline-flex;
  gap: 10px;
  left: 570px;
  position: absolute;
  top: 769px;
}

.button-23 {
  flex: 0 0 auto;
  position: relative;
}

.indicators-container-5 {
  align-items: flex-start;
  display: flex;
  gap: 3px;
  position: relative;
  width: 81px;
}

.shape-11 {
  background-color: var(--red45);
  border-radius: 100px;
  height: 4px;
  position: relative;
  width: 23px;
}

.shape-10 {
  background-color: var(--black20);
  border-radius: 100px;
  flex: 1;
  flex-grow: 1;
  height: 4px;
  position: relative;
}

.icon-task-5 {
  height: 20px;
  margin-top: 2867px;
  width: 23px;
}
</style>
