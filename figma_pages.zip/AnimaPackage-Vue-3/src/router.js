import Vue from "vue";
import Router from "vue-router";
import PopUpHowToPlay6 from "./components/PopUpHowToPlay6";
import PopUpHowToPlay5 from "./components/PopUpHowToPlay5";
import PopUpHowToPlay4 from "./components/PopUpHowToPlay4";
import PopUpHowToPlay3 from "./components/PopUpHowToPlay3";
import PopUpHowToPlay2 from "./components/PopUpHowToPlay2";
import Frame from "./components/Frame";
import {
  popUpHowToPlay6Data,
  popUpHowToPlay5Data,
  popUpHowToPlay4Data,
  popUpHowToPlay3Data,
  popUpHowToPlay2Data,
  frameData,
} from "./data";

Vue.use(Router);

export default new Router({
  mode: "history",
  routes: [
    {
      path: "/popup-how-to-play-6",
      component: PopUpHowToPlay6,
      props: {
        iconTask:
          "https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e0ef6bc6ae027f96f3776/img/---icon--task-@2x.png",
        title: "Type to Ending",
        image8:
          "https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e100d40ace40448c5fca5/img/image-8.png",
        xFormProps: popUpHowToPlay6Data.xFormProps,
        textContainerProps: popUpHowToPlay6Data.textContainerProps,
      },
    },
    {
      path: "/popup-how-to-play-5",
      component: PopUpHowToPlay5,
      props: {
        title: "Type to Ending",
        image7:
          "https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e0faf9b0fed44b746bebe/img/image-7.png",
        iconTask:
          "https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e0ef6bc6ae027f96f3776/img/---icon--task-@2x.png",
        xFormProps: popUpHowToPlay5Data.xFormProps,
        textContainerProps: popUpHowToPlay5Data.textContainerProps,
      },
    },
    {
      path: "/popup-how-to-play-4",
      component: PopUpHowToPlay4,
      props: {
        title: "Type to Ending",
        image5:
          "https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e0f50dc93a85589971944/img/image-5.png",
        image6:
          "https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e0f50dc93a85589971944/img/image-6.png",
        iconTask:
          "https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e0ef6bc6ae027f96f3776/img/---icon--task-@2x.png",
        xFormProps: popUpHowToPlay4Data.xFormProps,
        textContainerProps: popUpHowToPlay4Data.textContainerProps,
      },
    },
    {
      path: "/popup-how-to-play-3",
      component: PopUpHowToPlay3,
      props: {
        title: "Type to Ending",
        image4:
          "https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e0f31dc93a85589971943/img/image-4.png",
        iconTask:
          "https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e0ef6bc6ae027f96f3776/img/---icon--task-@2x.png",
        xFormProps: popUpHowToPlay3Data.xFormProps,
        textContainerProps: popUpHowToPlay3Data.textContainerProps,
        containerProps: popUpHowToPlay3Data.containerProps,
      },
    },
    {
      path: "/popup-how-to-play-2",
      component: PopUpHowToPlay2,
      props: {
        title: "Type to Ending",
        image3:
          "https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e0ef6bc6ae027f96f3776/img/image-3.png",
        iconTask:
          "https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e0ef6bc6ae027f96f3776/img/---icon--task-@2x.png",
        xFormProps: popUpHowToPlay2Data.xFormProps,
        textContainerProps: popUpHowToPlay2Data.textContainerProps,
        containerProps: popUpHowToPlay2Data.containerProps,
      },
    },
    {
      path: "*",
      component: Frame,
      props: {
        title: "Type to Ending",
        image2:
          "https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e0e9940ace40448c5fca3/img/image-2.png",
        iconTask:
          "https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673e0e9940ace40448c5fca3/img/---icon--task-@2x.png",
        xFormProps: frameData.xFormProps,
        textContainerProps: frameData.textContainerProps,
        containerProps: frameData.containerProps,
      },
    },
  ],
});
