export const container1Data = {
    text: "Profile",
};

export const container2Data = {
    text: "Create Room",
};

export const container3Data = {
    text: "Enter Room",
};

export const container4Data = {
    text: "Sign Out",
    className: "container",
};

export const xMainData = {
    title: "Type to Ending",
    id: "ID",
    pw: "PW",
    rememberMe: "remember me",
    iconMediaPlay: "https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673df1608bbac2c0338db9f5/img/---icon--media-play-@2x.png",
    text: "How to play",
    container1Props: container1Data,
    container2Props: container2Data,
    container3Props: container3Data,
    container4Props: container4Data,
};

