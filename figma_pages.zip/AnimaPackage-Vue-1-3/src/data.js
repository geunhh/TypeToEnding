export const container1Data = {
    text: "Profile",
};

export const container2Data = {
    text: "Create Room",
};

export const container3Data = {
    text: "Enter Room",
};

export const container4Data = {
    text: "Sign Out",
    className: "container",
};

export const xMainData = {
    id: "ID",
    pw: "PW",
    rememberMe: "remember me",
    title: "Type to Ending",
    iconMediaPlay: "https://cdn.animaapp.com/projects/673df13276e2d7568d4b019c/releases/673df1608bbac2c0338db9f5/img/---icon--media-play-@2x.png",
    text1: "How to play",
    heading: "영화관 코드를 입력해주세요",
    text2: "3F7D",
    text3: "확인",
    container1Props: container1Data,
    container2Props: container2Data,
    container3Props: container3Data,
    container4Props: container4Data,
};

